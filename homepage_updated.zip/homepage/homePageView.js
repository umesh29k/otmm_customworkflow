(function(exports) {
	/* Custom View Example */
	var HomeView = exports.csHomeView = otui.define(
			"csHomeView ", function() {
				this.properties = {
					'name' : 'csHomeView'/* Name of the view */
				};
				/* Function called to create the content for this view. */


				/* If not defined, exception is raised. */
				this._initContent =
				/* Note that initContent functions must always have a name. */
				function initCustHomeView1(self, placeContent) {
					//console.log("inside  initCustHomeView1 init");
					/* get the template with the id="content" */
					var template = this.getTemplate("CustomHomeViewTemplate", undefined, $);
					//console.log("template:"+template);
					
				var session ="";
				if (sessionStorage && sessionStorage.session) {
					session = JSON.parse(sessionStorage.session);
				}
				//console.log("seesion id:"+session.id);
				
				
				var urlsys = "/EnterpriseAdminConfig/prefSystem?sId="+session.id;
				var sysId = "0";
				$.ajax({url:urlsys,success:function(res){
					sysId = res;
					
					//console.log("sysId:"+sysId);
					$("#arc2session").val(session.id);
					$("#arc-home-widgets").css({"display":"none"});
					if(sysId.trim()=='1'){
						
						loadPheHomePageData(session); 	
					
					}
					if(sysId.trim()=='2'){
						
						loadItmHomePageData(session); 	
					
					}
					if(sysId.trim()=='3'){
						
						loadVaultHomePageData(session); 	
					
					}
					if(sysId.trim()=='4'){//theatrical domestic
						
						loadGenericHomePageData(session); 	
					
					}
					if(sysId.trim()=='5'){
						
						loadInflightHomePageData(session); 	
					
					}
					if(sysId.trim()=='6'){
						
						loadPdtdHomePageData(session); 	
					
					}
					if(sysId.trim()=='7'){
						
						loadLicHomePageData(session); 	
					
					}
					if(sysId.trim()=='8'){
						
						loadPressKitHomepageData(session); 	
					
					}
					if(sysId.trim()=='9'){
						
						loadRepertoryHomepageData(session); 	
					
					}
					if(sysId.trim()=='10'){
						
						loadTVDistributionHomepageData(session); 	
					
					}
					if(sysId.trim()=='11'){
						
						loadPheiMarketingHomePageData(session); 	
					
					}
					if(sysId.trim()=='12' || sysId.trim()=='17'){
						
						loadHiveHomePageData(session);
						
					}
					if(sysId.trim()=='21'){
						
						loadPPCHomepageData(session);
						
					}
				},error:function(res){}});	

					placeContent(template);
					var self = this;
					if (this.storedProperty("isTimeout")) {
						this.storedProperty("isTimeout", undefined);
						showError.call(this, timeoutError);
					}
					$(".ot-homescreen").on("click",".scrollingHotSpotLeftVisible",function() {
				//console.log("inside left");
				var numFolders=document.getElementById('numberOfRelFolders').value;
				for(var i=0;i< numFolders;i+=1){
				$(this).siblings(".scrollWrapper_"+i).children(".scrollableArea").animate({'left' : 0}, 1, function(){    
					//move the last item and put it as first item            	
					$(this).find(".carousel-tile:last").after($(this).find(".carousel-tile:first"));					
					//console.log($(this).find(".carousel-tile:first"));
				});
			}
			});
			$(".ot-homescreen").on("click",".scrollingHotSpotRightVisible",function() {
				//console.log("inside Right");
				var numFolders=document.getElementById('numberOfRelFolders').value;
				for(var i=0;i<numFolders;i+=1){
				$(this).siblings(".scrollWrapper_"+i).children(".scrollableArea").animate({'left' : 0}, 1, function(){    
					//move the last item and put it as first item            	
					$(this).find(".carousel-tile:first").before($(this).find(".carousel-tile:last"));
					//console.log($(this).find(".carousel-tile:last"));
							});
						}	
					});
				}
			}

	); /* END: csRecentView definition block */

	/* Specify the route for the view, */
	/* binding an optional "display" parameter to the URL */
	/* The route should then load the "main" layout template */
	/* using the full-page for content */
	var csOpenView = csHomeView.route.as("csHome", /* URL format */
	otui.withTemplate("main"), /* Load the layout template */
	csHomeView.route.to() /* Route to the new View */
	);

	/* (after the csOpenView definition) */
	/* Bind that route URL into the named route "open". */
	csHomeView.route.define("open", csOpenView);

	/* Create a menu item for custom view */
	otui.ready(function() {
						otui.Menus
								.register(
										{
											/* Unique name for the menu entry */
											'name' : 'cs_Home_page',
											icon : {
												touch:"/otmm/ux-html/customizations/common/img/menu/sidemenu_home24_sprite.png",
												desktop:"/otmm/ux-html/customizations/common/img/home18_white.png"
											},
											icondisplaystyle:"inline-block",
											
											/* Display name for menu entry */
											title:{touch:otui.tr("Home23")},
											menuimagehover:otui.tr("Home"),
											readTitle:otui.tr("Home"),
											'setup' : function() {
												return !otui.UserFETManager.isTokenAvailable("HIDE_HOME_PAGE");
											},

											/* Action on mouse click */
											'select' : csHomeView.route
													.use("open", true)
										}, 1);
					}, true);
})(window);