function loadPPCHomepageData(homePageSession)
{
	$("#ppc-home").css({"display":"block"});
	$("#home_folder_ppc_container").css({"display":"inline-block"});
	$("#titleLoadingDiv").css({"display":"block", "margin-left":"40%"});
	var url_pk = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=''";
	$.ajax({url:url_pk,success:function(res){
		var homePageDataStr=loadPPCHomePageTitles(res);
		$("#home_folder_ppc_current_titles").html(homePageDataStr);
		$(".ppc-home-title-hover").each(function(){
			var ih=$(this).next().height()+"px";
			var iw=$(this).next().width()+"px";
			$(this).css({"height":ih,"width":iw});});
			$(".ot-homescreen").scroll(function(){
				$(".ppc-home-title-hover").each(function(){
					var it=$(this).next().position().top;$(this).css({"top":it});});
					});
			
			var hsh=$("#home_folder_ppc_container").find(".ppc_sec_header").html();
			hsh=hsh+"<span class=\"ppc-all-titles\">[&nbsp;<a href=\"/otmm/ux-html/?p=title\">View All Titles</a>&nbsp;]</span>";$("#home_folder_ppc_container").find(".ppc_sec_header").html(hsh);	
			
			},
			error:function(res){}
			});
		if(otui.UserFETManager.isTokenAvailable("IMPORT")){
			$("#ppc-upload-cell").css({"display":"block"});
			$("#ppc-upload").css({"display":""});
			$("#mm_upload_master_ppc").css({"display":"inline-table","width":"100%","height":$("#ppc-upload").height()+"px"});
			}
		$("#titleLoadingDiv").css({"display":"none"});
}

function loadPPCHomePageTitles(homePageData)
{
	var homePageLinkList=homePageData.homePageLinkList;
	var companyName = homePageData.homePageLinkList[0].companyName;
	var homePageDataStr="";
	var hasWatemarkTemplateFET = otui.UserFETManager.isTokenAvailable("PP_WATERMARK_TEMPLATE");
	if(homePageLinkList!='')
	{
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	  {
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   if(homePageTitleList!='')
	   {
	   numberOfFolders++;
	   homePageDataStr += "<h4 class='card-title' >" + folderName + "</h4>";
	   homePageDataStr += "<div class='owl-carousel' id='owl-carousel_" + i + "'>";
	   for(var j=0;j<homePageTitleList.length;j++)
	   {
				var homePageTitlesDto=homePageTitleList[j];
				homePageDataStr+="<div class='item'" + " onmouseover=\"javascript:this.getElementsByClassName('ppc-home-title-hover')[0].style.display='inline-flex';\"" + " onmouseout=\"javascript:this.getElementsByClassName('ppc-home-title-hover')[0].style.display='none';\"" + " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="+homePageTitlesDto.titleId+"';\">";
				homePageDataStr += "<a href='/otmm/ux-html/?p=sammeTitle&title=" + homePageTitlesDto.titleId + "'>";
				if(homePageTitlesDto.ppThumbUoiId =='' || homePageTitlesDto.ppThumbUoiId == 'null' || homePageTitlesDto.ppThumbUoiId == null){	
					homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
				}else {
					if(!hasWatemarkTemplateFET){
						if(homePageTitlesDto.templateId=='' || homePageTitlesDto.templateId== 'null' || homePageTitlesDto.templateId== null){
							homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"/otmmapi/v6/renditions/" +homePageTitlesDto.ppThumbUoiId+ "\"/>";
						}else{
							homePageDataStr+="<<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/preview_unavailable.png" + "\"/>";
						}

					}else{
						homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName + "'src=\"/otmmapi/v6/renditions/" +homePageTitlesDto.ppThumbUoiId+ "\"/>";
					}
					
				}
				//homePageDataStr+="<br/>" + homePageTitlesDto.titleName+"</a></div>";
				homePageDataStr+="</a></div>";
		   }
		   homePageDataStr+="</div>";
	   }
	}
	  if(companyName != null){
		   $("#ppc-welcome-company").html("Welcome "+companyName);
		}else{
		   $(".ppc_welcome_sec_header").css({"display":"none"}); 
		}
	}
	return homePageDataStr;
}
