function loadPheHomePageData(homePageSession) {
   //console.log("inside PHE homepage");
   /*Home page - PHE Start*/
   $("#arc2session").val(homePageSession.id);
   $("#arc-home-widgets").css({
      "display": "none"
   });
   $("#phe-home").css({
      "display": "block"
   });
   $("#home_folder_phe_features_container").css({
      "display": "inline-block"
   });
   $("#home_folder_phe_genre_container").css({
      "display": "inline-block"
   });
   var url_phe = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=releases";
   $.ajax({
      error: function (res) {},
      success: function (res) {
		 console.log("Res: " + JSON.stringify(res))
         var pheres = loadPheHomePageReleases(res);
      },
      url: url_phe
   });

   var url_phe_features = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=features";

   $.ajax({
      error: function (res) {},
      success: function (res) {
         var pheFeatures = loadPheHomePageFeatures(res);
      },
      url: url_phe_features
   });

   $("#mm_upload_master").css({
      "display": "none"
   });

   if (otui.UserFETManager.isTokenAvailable("IMPORT")) {
      $("#phe-upload-cell").css({
         "display": "block"
      });
      $("#phe-upload").css({
         "display": ""
      });
      $("#mm_upload_master_phe").css({
         "display": "inline-table",
         "height": $("#phe-upload").height() + "px",
         "width": "100%"
      });
   }

}

function loadPheHomePageReleases(homePageData) {
   //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
   var homePageLinkList = homePageData.homePageLinkList;
   var homePageDataStr = "";
   if (homePageLinkList != '') {
      var numberOfFolders = 0;
      for (var i = 0; i < homePageLinkList.length; i++) {
         var homePageTitleList = homePageLinkList[i].homePageTitleList;
         var folderName = homePageLinkList[i].folderName;
         if (homePageTitleList != '') {
            numberOfFolders++;
            homePageDataStr += "<h4 class='card-title' >" +
            folderName.substring(folderName.indexOf("_") + 1) + "</h4>";
            var numberOfTitles = homePageTitleList.length;
            homePageDataStr+="<div class='owl-carousel' id='owl-carousel_"+i+"'>";
            for (var j = 0; j < homePageTitleList.length; j++) {
               var homePageTitlesDto = homePageTitleList[j];
               homePageDataStr += "<div" + " class='item' onmouseover=\"javascript:this.getElementsByClassName('phe-home-title-hover')[0].style.display='inline-flex';\"" +
                  " onmouseout=\"javascript:this.getElementsByClassName('phe-home-title-hover')[0].style.display='none';\"" +
                  " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title=" + homePageTitlesDto.titleId + "';\">";
               homePageDataStr+="<a href='/otmm/ux-html/?p=sammeTitle&title="+ homePageTitlesDto.titleId + "'>";
               //console.log("title data:"+JSON.stringify(homePageTitlesDto));			
               if (homePageTitlesDto.screenResObjId == "") {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
               } else {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"/otmmapi/v6/renditions/" + homePageTitlesDto.screenResObjId + "\"/>";
				  //console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
               }
               homePageDataStr += "</a></div>";
            }

            homePageDataStr += "</div></br><input type='hidden' name='numberOfTitles_" + i + "' value=" + numberOfTitles + " id='numberOfTitles_" + i + "'/>";
         }
      }
      homePageDataStr += "<input type='hidden' name='numberOfRelFolders' value=" + numberOfFolders + " id='numberOfRelFolders'/>";
   }
   //console.log("inside homepage js homePageDataStr:"+homePageDataStr);

   /*scroll code*/
   $("#phe-home-section").html(homePageDataStr);
   var numFolders = document.getElementById('numberOfRelFolders').value;
   //console.log("numFolders:"+numFolders);

   for (var i = 0; i < numFolders; i = i + 1) {

      var numTitles = document.getElementById('numberOfTitles_' + i).value;
      //console.log("numTitles:"+numTitles);
      var scrollwrapperclassvar = "scrollWrapper_" + i;
      $("#phe-home-section-div_" + i).smoothDivScroll({
         autoScrollingMode: "empty",
         hotSpotScrolling: false,
         manualContinuousScrolling: false,
         mousewheelScrolling: "allDirections",
         scrollWrapperClass: scrollwrapperclassvar,
         touchScrolling: false
      });
      $(".scrollableArea").css("width", "200%");
      $("." + scrollwrapperclassvar).css({
         "height": "100%",
         "overflow": "hidden",
         "position": "relative",
         "width": "100%"
      });
      if (numTitles > 5) {
         $("." + scrollwrapperclassvar).hover(function () {
            //console.log("phe numTitles:" + numTitles);
            var sh = $(this).height() + "px";
            var pt = $(this).position().top + "px";
            var lArrow = $(this).parent().find(".scrollingHotSpotLeft");
            $(lArrow).addClass("scrollingHotSpotLeftVisible");
            $(lArrow).css({
               "display": "block",
               "height": sh,
               "top": pt
            });
            var rArrow = $(this).parent().find(".scrollingHotSpotRight");
            $(rArrow).addClass("scrollingHotSpotRightVisible");
            $(rArrow).css({
               "display": "block",
               "height": sh,
               "top": pt
            })
         })
      } else {
         //console.log("inside else num title");
         $(".phe-home-section-div_" + i).smoothDivScroll("disable");
         $(".scrollableArea").css("width", "200%")
      }
   }

   return homePageDataStr;
}

function loadPheHomePageFeatures(homePageData) {
   //console.log("inside loadPheHomePageFeatures"+JSON.stringify(homePageData));
   var homePageDataStr = "";
   var roleName = (JSON.parse(sessionStorage.session)).role_name;
   //console.log("roleName:"+roleName);	
   var homePageLinkList = homePageData.homePageLinkList;
   for (var i = 0; i < homePageLinkList.length; i++) {
      var folderName = homePageLinkList[i].folderName;
      var folderId = homePageLinkList[i].folderId;

      if (!(roleName.toLowerCase() == 'phe external' &&
            (folderName.toLowerCase() == "phe tv spot" ||
               folderName.toLowerCase() == "retail style guides & templates"
            )
         ) &&
         !(roleName.toLowerCase() == "phe regular - no upload" &&
            folderName.toLowerCase() == "retail style guides & templates"
         )
      ) {
         //homePageDataStr+="<div onclick=\"javascript:";
         //homePageDataStr+="FolderManager.performAdvancedSearch('"+ folderId
         //+"','*',"
         //+ "{"
         //+ "'names':['"+ homePageData.homePageFolderName +"','"+ folderName+"'],"
         //+ "'ids':['"+ homePageData.homePageFolderFolderId+"','"+ folderId+"']"
         //+ "},"
         //+ "'"+homePageData.homePageSearchconfigId+"','"+homePageData.homePageSearchsearchName+"',"
         //+"{'search_condition':[]},"
         //+ "'ARTESIA.FIELD.DATE IMPORTED','desc',undefined,'en_US','3','Metadata and File Content');\">";
         homePageDataStr += "<a href='/otmm/go/folder/" + folderId + "'><div>";
         homePageDataStr += folderName + "</div></a>";
      }


   }

   if (homePageDataStr.trim() !== '') {
      $("#home_folder_phe_features_container").css({
         "display": "inline-block"
      });
      $("#home_folder_phe_features").html(homePageDataStr);
   }

   //add extra link
   var res1 = "";
   var query = window.location;

   if (query.host == "enterprise.viacomcbs.com" || query.host == "enterpriseuat.viacomcbs.com" || query.host == "10.224.79.142:11090") {
      res1 = "<div onclick=\"javascript:showRequestForm();\">Request Form</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'452','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'444','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'448','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'106','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div>";
      if (roleName.toLowerCase() != 'phe external') {
         res1 = res1 + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'276','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'141','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'277','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Backlot</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'57','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'1','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'5','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'328','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'237','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'12','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'16','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'17','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'74','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'255','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'96','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'132','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'133','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'134','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'136','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'138','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'178','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'199','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'203','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'208','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'212','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'228','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'235','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Multi-Title</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'298','left_paren':'(','relational_operator':'and','right_paren':')'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Ratings</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'430','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'459','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'460','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'458','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'449','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Templates</div>";
      }
   } else if (query.host == "10.224.5.113:11090") {
      res1 = "<div onclick=\"javascript:showRequestForm();\">Request Form</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'452','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'444','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'448','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'106','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div>";
      if (roleName.toLowerCase() != 'phe external') {
         res1 = res1 + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'276','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'141','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'277','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Backlot</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'57','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'1','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'5','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'328','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'237','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'12','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'16','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'17','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'74','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'255','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'96','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'132','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'133','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'134','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'136','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'138','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'178','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'199','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'203','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'208','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'212','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'228','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'235','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Multi-Title</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'298','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'430','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'459','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'460','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'458','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'449','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">ToolBox</div>";
      }
   }

   if (res1.trim() !== '') {
      $("#home_folder_phe_features_container").css({
         "display": "inline-block"
      });
      $("#home_folder_phe_features1").html(res1);
   }
   //console.log("homePageDataStr:"+homePageDataStr);
   return homePageDataStr;

}