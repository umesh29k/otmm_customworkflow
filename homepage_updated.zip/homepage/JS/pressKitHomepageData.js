function loadPressKitHomepageData(homePageSession) {
   $("#presskit-home").css({
      "display": "block"
   });
   $("#home_folder_presskit_container").css({
      "display": "inline-block"
   });
   var url_pk = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=''";
   $.ajax({
      url: url_pk,
      success: function (res) {
         var homePageDataStr = loadPresskitHomePageTitles(res);
         $("#home_folder_presskit_current_titles").html(homePageDataStr);
         $(".presskit-home-title-hover").each(function () {
            var ih = $(this).next().height() + "px";
            var iw = $(this).next().width() + "px";
            $(this).css({
               "height": ih,
               "width": iw
            });
         });
         $(".ot-homescreen").scroll(function () {
            $(".presskit-home-title-hover").each(function () {
               var it = $(this).next().position().top;
               $(this).css({
                  "top": it
               });
            });
         });
         var hsh = $("#home_folder_presskit_container").find(".presskit_sec_header").html().trim();
         hsh = hsh + "<span class=\"presskit-all-titles\">[ <a href=\"/otmm/ux-html/?p=title\">View All Titles</a> ]</span>";
         $("#home_folder_presskit_container").find(".presskit_sec_header").html(hsh);
      },
      error: function (res) {}
   });
   if (otui.UserFETManager.isTokenAvailable("IMPORT")) {
      $("#presskit-upload-cell").css({
         "display": "block"
      });
      $("#presskit-upload").css({
         "display": ""
      });
      $("#mm_upload_master_presskit").css({
         "display": "inline-table",
         "width": "100%",
         "height": $("#presskit-upload").height() + "px"
      });
   }

}

function loadPresskitHomePageTitles(homePageData) {

   var homePageLinkList = homePageData.homePageLinkList;
   var homePageDataStr = "";
   if (homePageLinkList != '') {
      var numberOfFolders = 0;
      for (var i = 0; i < homePageLinkList.length; i++) {
        var homePageTitleList = homePageLinkList[i].homePageTitleList;
		var folderName = homePageLinkList[i].folderName.substring(homePageLinkList[i].folderName.indexOf("_") + 1);
		numberOfFolders++;
        homePageDataStr += "<h4 class='card-title' >" + folderName + "</h4>";
        homePageDataStr += "<div class='owl-carousel' id='owl-carousel_" + i + "'>";
         if (homePageTitleList != '') {
            for (var j = 0; j < homePageTitleList.length; j++) {
               var homePageTitlesDto = homePageTitleList[j];

               homePageDataStr += "<div class='item'" + " onmouseover=\"javascript:this.getElementsByClassName('presskit-home-title-hover')[0].style.display='inline-flex';\"" + " onmouseout=\"javascript:this.getElementsByClassName('presskit-home-title-hover')[0].style.display='none';\"" + " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title=" + homePageTitlesDto.titleId + "';\">";
			   homePageDataStr += "<a href='/otmm/ux-html/?p=sammeTitle&title=" + homePageTitlesDto.titleId + "'>";
               if (homePageTitlesDto.presskitThumbUoiId == '' || homePageTitlesDto.presskitThumbUoiId == null) {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
               } else {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"/otmmapi/v6/renditions/" + homePageTitlesDto.presskitThumbUoiId + "\"/>";
               }
               homePageDataStr += "</a></div>";
            }
         }
		 homePageDataStr += "</div>";
      }
   }
   return homePageDataStr;
   //$("#home_folder_lic_current_titles").html(homePageDataStr);
}