function loadLicHomePageData(homePageSession)
{
	//console.log("inside Lic homepage");
	
	$("#arc2session").val(homePageSession.id);
	$("#arc-home-widgets").css({"display":"none"});
	$("#lic-home").css({"display":"block"});
	$("#home_folder_lic_container").css({"display":"inline-block"});
	var url_lic="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=''";
	
	$.ajax({error:function(res){},success:function(res){
	//console.log("inside lic home");	
	loadLicHOmePageTitles(res);
	
	$(".lic-home-title-hover").each(function(){
		var ih=$(this).next().height()+"px";
		var iw=$(this).next().width()+"px";
		$(this).css({"height":ih,"width":iw})
	});
	
	$(".ot-homescreen").scroll(function(){$(".lic-home-title-hover").each(
	function(){
	var it=$(this).next().position().top;$(this).css({"top":it})})});
	
	var hsh=$("#home_folder_lic_container").find(".lic_sec_header").html().trim();
	hsh=hsh+"<span class=\"lic-all-titles\">[&nbsp;<a href=\"/otmm/ux-html/?p=title\">View All Titles</a>&nbsp;]</span>";
	},
	url:url_lic}
	);
	
	if(otui.UserFETManager.isTokenAvailable("IMPORT")){
		$("#lic-upload-cell").css({"display":"block"});
		$("#lic-upload").css({"display":""});
		$("#mm_upload_master_lic").css({"display":"inline-table","height":
		$("#lic-upload").height()+"px","width":"100%"});
	}
}

function loadLicHOmePageTitles(homePageData)
{
	var homePageLinkList=homePageData.homePageLinkList;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
		var numberOfFolders=0;
		for(var i=0;i<homePageLinkList.length;i++)
		{
		   var homePageTitleList=homePageLinkList[i].homePageTitleList;
		   if(homePageTitleList!='')
		   {
		   numberOfFolders++;
		   for(var j=0;j<homePageTitleList.length;j++)
			   {
					var homePageTitlesDto=homePageTitleList[j];
					homePageDataStr+="<div class='item' onmouseover=\"javascript:this.getElementsByClassName('titleOverlay')[0].style.display='inline-flex';\"" + " onmouseout=\"javascript:this.getElementsByClassName('titleOverlay')[0].style.display='none';\">";
					homePageDataStr+="<a href='/otmm/ux-html/?p=sammeTitle&title="+ homePageTitlesDto.titleId + "'>";
					if(homePageTitlesDto.licensingThumbUoiId=='' || homePageTitlesDto.licensingThumbUoiId==null){
						homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}else{
							homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName
										+ "' src=\"/otmmapi/v6/renditions/"
										+homePageTitlesDto.licensingThumbUoiId + "\"/>";
					}
					homePageDataStr+="</a><br/><span style='font-family: arial black;'>"+homePageTitlesDto.titleName+"</span></div>";
			   }
		   }
		}
	}
	$("#home_folder_lic_current_titles").html(homePageDataStr);
}
