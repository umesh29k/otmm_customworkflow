function loadVaultHomePageData(homePageSession) {
   console.log("inside PHEI homepage");
   $("#phei-home").css({
      "display": "block"
   });
   $("#home_folder_phei_features_container").css({
      "display": "inline-block"
   });
   $("#home_folder_phei_genre_container").css({
      "display": "inline-block"
   });
   var url_phei = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=releases";

   $.ajax({
      error: function (res) {},
      success: function (res) {
         /*^*/
         console.log("Res: " + JSON.stringify(res))
         loadVaultHomePageTitles(res);
      },
      url: url_phei
   })

   var url_phei_features = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=features";
   $.ajax({
      error: function (res) {},
      success: function (res) {

         /****var vaultRes=loadVaultHomePageFeatures(res);****/
         var vaultRes = loadVaultHomePageFeatures(res);
         if (homePageDataStr.trim() !== '') {
            $("#home_folder_phei_features").html(vaultRes);
         }
      },
      url: url_phei_features
   });

   if (otui.UserFETManager.isTokenAvailable("IMPORT")) {
      $("#phei-upload-cell").css({
         "display": "block"
      });
      $("#phei-upload").css({
         "display": ""
      });
      $("#mm_upload_master_phei").css({
         "display": "none"
      });
   }
}

function loadVaultHomePageFeatures(homePageData) {
   console.log("inside homepage file method name loadVaultHomePageFeatures" + JSON.stringify(homePageData));
   var roleName = (JSON.parse(sessionStorage.session)).role_name;
   var vaultRes = getFolderBasedFeatures(homePageData);
   var query = window.location;
   //vaultRes=vaultRes+"<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition':[{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'ARTESIA.FIELD.DATE IMPORTED','relational_operator_id': 'ARTESIA.OPERATOR.DATE.IS YESTERDAY','value': ''},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '12','left_paren':'(','relational_operator': 'and'},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '17','relational_operator': 'or','right_paren':')'}]}, 'ARTESIA.FIELD.DATE IMPORTED','desc', 'en_US','3','Metadata and File Content');\">Uploads last 24 hours</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI MAT NUMBER','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '*0*'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">MAT Assets</div>";
   if (query.host == "uat-enterprise.paramount.com" || query.host == "enterprise.paramount.com") {
      vaultRes = vaultRes + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition':[{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'ARTESIA.FIELD.DATE IMPORTED','relational_operator_id': 'ARTESIA.OPERATOR.DATE.IS YESTERDAY','value': ''},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '12','left_paren':'(','relational_operator': 'and'},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '17','relational_operator': 'or','right_paren':')'}]}, 'ARTESIA.FIELD.DATE IMPORTED','desc', 'en_US','3','Metadata and File Content');\">Uploads last 24 hours</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '44','left_paren': '(','relational_operator': 'and'}, {'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '45','right_paren': ')','relational_operator': 'or'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '13','relational_operator': 'and'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Templates</div>";

      if (roleName.toLowerCase() == 'phei admin') {
         vaultRes = vaultRes + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1247', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.STATUS','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '8'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Deleted Assets</div>";
      }

      vaultRes = vaultRes + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI MAT NUMBER','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '*0*'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">MAT Assets</div>";
   }
   /*else if(query.host == "10.224.5.113:11090")
		{
			vaultRes=vaultRes+"<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition':[{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'ARTESIA.FIELD.DATE IMPORTED','relational_operator_id': 'ARTESIA.OPERATOR.DATE.IS YESTERDAY','value': ''},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '12','left_paren':'(','relational_operator': 'and'},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '17','relational_operator': 'or','right_paren':')'}]}, 'ARTESIA.FIELD.DATE IMPORTED','desc', 'en_US','3','Metadata and File Content');\">Uploads last 24 hours</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '44','left_paren': '(','relational_operator': 'and'}, {'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '45','right_paren': ')','relational_operator': 'or'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '13','relational_operator': 'and'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Templates</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'683', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.STATUS','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '8'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Deleted Assets</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI MAT NUMBER','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '*0*'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">MAT Assets</div>";
		}*/
   return vaultRes;
}

function loadVaultHomePageTitles(homePageData) {
   //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
   var homePageLinkList = homePageData.homePageLinkList;
   var homePageDataStr = "";
   if (homePageLinkList != '') {
      var numberOfFolders = 0;
      for (var i = 0; i < homePageLinkList.length; i++) {
         var homePageTitleList = homePageLinkList[i].homePageTitleList;
         // var folderName=homePageLinkList[i].folderName;
		 var folderName = homePageLinkList[i].folderName.substring(homePageLinkList[i].folderName.indexOf("_") + 1);
		 if (homePageTitleList != '') {
            numberOfFolders++;
		    homePageDataStr += "<h4 class='card-title' >" + folderName + "</h4>";
		    homePageDataStr += "<div class='owl-carousel' id='owl-carousel_" + i + "'>";
            var numberOfTitles = homePageTitleList.length;
            for (var j = 0; j < homePageTitleList.length; j++) {
               var homePageTitlesDto = homePageTitleList[j];
               homePageDataStr += "<div class='item'  onmouseover=\"javascript:this.getElementsByClassName('phei-home-title-hover')[0].style.display='inline-flex';\"  onmouseout=\"javascript:this.getElementsByClassName('phei-home-title-hover')[0].style.display='none';\"  onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title=" + homePageTitlesDto.titleId + "';\">";
               homePageDataStr += "<a href='/otmm/ux-html/?p=sammeTitle&title=" + homePageTitlesDto.titleId + "'>";
               //console.log("title data:"+JSON.stringify(homePageTitlesDto));			
               if (homePageTitlesDto.screenResObjId == "") {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" +  "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
               } else {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "'  src=\"/otmmapi/v6/renditions/" + homePageTitlesDto.screenResObjId + "\"/>";                  //console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
               }
               homePageDataStr += "</a></div>";
            }
            homePageDataStr += "</div><input type='hidden' name='numberOfTitles' value=" + numberOfTitles + " id='numberOfTitles'/>";
         }
      }
      homePageDataStr += "<input type='hidden' name='numberOfRelFolders' value=" + numberOfFolders + " id='numberOfRelFolders'/>";
   }
   //console.log("inside homepage js homePageDataStr:"+homePageDataStr);


   $("#phei-home-section").html(homePageDataStr);
   loadVaultCarousel(numberOfFolders);
   return homePageDataStr;


   /***var numTitles=document.getElementById('numberOfTitles').value;
	var scrollwrapperclassvar = "scrollWrapper_0";

	$(".scrollableArea").css("width","200%");
	$(".phei-home-section-div").smoothDivScroll({
                autoScrollingMode: "empty",
                hotSpotScrolling: false,
                manualContinuousScrolling: false,
                mousewheelScrolling: "allDirections",
      		  scrollWrapperClass: scrollwrapperclassvar,
                touchScrolling: false});
	
	$(".scrollableArea").css("width","200%");
	if(numTitles>5)
	{
		$(".scrollWrapper_0").hover(
		function(){
			var sh=$(this).height()+"px";
			var pt=$(this).position().top+"px";
			var lArrow=$(this).parent().find(".scrollingHotSpotLeft");
			$(lArrow).addClass("scrollingHotSpotLeftVisible");
			$(lArrow).css({"display":"block","height":sh,"top":pt});
			var rArrow=$(this).parent().find(".scrollingHotSpotRight");
			$(rArrow).addClass("scrollingHotSpotRightVisible");
			$(rArrow).css({"display":"block","height":sh,"top":pt})
			});
	}			
	else
	{
		$(".phei-home-section-div").smoothDivScroll("disable");
		$(".scrollableArea").css("width","200%")
	}****/
}

function loadVaultCarousel(numberOfFolders) {
   let i = 0;
   do {
      $("#owl-carousel_" + i).owlCarousel({
         autoplay: true,
         autoplaytimeout: 300,
         autoplayhoverpause: true,
         dots: false,
         center: false,
         margin: 10,
         nav: true,
         loop: false,
         rewind: true,
         responsive: {
            0: {
               items: 1
            },

            600: {
               items: 4
            },

            1024: {
               items: 4
            },

            1366: {
               items: 5
            }
         }
      });
      i++;
   }
   while (i < numberOfFolders);
}

function getHeaderFeatures(homePageData) {
   var homePageDataStr = "";
   var roleName = (JSON.parse(sessionStorage.session)).role_name;

   var homePageLinkList = homePageData.homePageLinkList;
   for (var i = 0; i < homePageLinkList.length; i++) {
      var folderName = homePageLinkList[i].folderName;
      var folderId = homePageLinkList[i].folderId;

      homePageDataStr += "<div><a href='/otmm/go/folder/" + folderId + "'><h4>";
      homePageDataStr += folderName + "</h4></a></div>";
   }

   return homePageDataStr;
}