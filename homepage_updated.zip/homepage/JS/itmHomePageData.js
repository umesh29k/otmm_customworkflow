function loadItmHomePageData(homePageSession)
{	

	$("#itm-home").css({"display":"inline-block"});
	$("#home_folder_itm_genre_container").css({"display":"inline-block"});
	var url_itm_current="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases"; 
	$.ajax({
		url:url_itm_current,
		success:function(res){
			
			var itmHomepage=loadItmHomePageTitles(res);
			$("#itm-home-section").html(itmHomepage);
			$(".itm-home-title-hover").each(
			function(){var ih=$(this).next().height()+"px";
			var iw=$(this).next().width()+"px"; 
			$(this).css({"height":ih,"width":iw});
			});
			
			$(".ot-homescreen").scroll(function(){$(".itm-home-title-hover").each(function(){var it=$(this).next().position().top;$(this).css({"top":it});});});
			},
			error:function(res){}
			});
			
	$("#mm_upload_master").css({"display":"none"});
	if(otui.UserFETManager.isTokenAvailable("IMPORT")){
		$("#itm-upload").css({"display":""});
		$("#itm-upload-cell").css({"display":"block"});
		$("#mm_upload_master_itm").css({"display":"inline-table","width":"100%","height":$("#itm-upload").height()+"px"});
		}		
	
}

function loadItmHomePageTitles(homePageData)
{	
	var homePageLinkList=homePageData.homePageLinkList;
	var searchId=homePageData.homePageSearchconfigId;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	    var numberOfFolders=0;
	   for(var i=0;i<homePageLinkList.length;i++)
	   {
		   var homePageTitleList=homePageLinkList[i].homePageTitleList;
		   var folderName=homePageLinkList[i].folderName;
		   numberOfFolders++;
		   if(homePageTitleList!='')
		   {
				homePageDataStr+= "<h4 class='card-title' >"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</h4>";
				homePageDataStr+="<div class='owl-carousel' id='owl-carousel_"+i+"'>";
				var numberOfTitles = homePageTitleList.length;
				for(var j=0;j<homePageTitleList.length;j++)
				{
					var homePageTitlesDto=homePageTitleList[j];
					homePageDataStr+="<div class='item' onmouseover=\"javascript:this.getElementsByClassName('titleOverlay')[0].style.display='inline-flex';\"" + " onmouseout=\"javascript:this.getElementsByClassName('titleOverlay')[0].style.display='none';\">"
					if(homePageTitlesDto.titleId=='999998')
					{						
						homePageDataStr+="<div>";
						homePageDataStr+="<a "+	"href=\"javascript:SearchManager.performKeywordSearch('"+homePageTitlesDto.titleId +	"||savedSearch||',undefined,undefined,"+searchId+");\">";
						homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\""+  				   "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" +"\"/></a>";
						homePageDataStr+="<br/><span style='font-family: arial black;'>"+ homePageTitlesDto.titleName+ "</span>";
						
					}
					else
					{
						homePageDataStr+="<a href=\"/otmm/ux-html/?p=title&title="+ homePageTitlesDto.titleId +"\">";
						if(homePageTitlesDto.screenResObjId==''){
							homePageDataStr+= "<div id='titleOverlay_"+j+"' class='titleOverlay' style='display:none'> <div id='titleText'>"+ homePageTitlesDto.titleName ;
							homePageDataStr+= " </div></div>";
							homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName
										+ "'  src=\"/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/></a>";
						}else{
								homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName
									+ "' src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/></a>";
						}
						homePageDataStr+="<br/><span style='font-family: arial black;'>" + homePageTitlesDto.titleName+"</span>";
					}
				}
			}
		}
	}
	return homePageDataStr;
}
