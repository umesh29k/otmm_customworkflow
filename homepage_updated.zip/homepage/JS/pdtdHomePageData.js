function loadPdtdHomePageData(homePageSession) {
   $("#arc2session").val(homePageSession.id);
   $("#arc-home-widgets").css({
      "display": "none"
   });
   $("#pdtd-home").css({
      "display": "block"
   });
   $("#home_folder_pdtd_features_container").css({
      "display": "inline-block"
   });
   $("#home_folder_pdtd_genre_container").css({
      "display": "inline-block"
   });
   var url_pdtd = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=releases";
   $.ajax({
      error: function (res) {},
      success: function (res) {
         //console.log("res:"+res);
         loadPdtdHomePageReleases(res);
      },
      url: url_pdtd
   });

   var url_pdtd_mktg_features = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=features";
   $.ajax({
      error: function (res) {},
      success: function (res) {
         if (res != null) {
            $("#home_folder_pdtd_features_container").css({
               "display": "inline-block"
            });
            $("#home_folder_pdtd_features").html(res)
         }
      },
      url: url_pdtd_mktg_features
   });

   $("#mm_upload_master").css({
      "display": "none"
   });
   //console.log("import:"+otui.UserFETManager.isTokenAvailable("IMPORT"));
   if (otui.UserFETManager.isTokenAvailable("IMPORT")) {
      $("#pdtd-upload-cell1").css({
         "display": "block"
      });
      $("#pdtd-upload").css({
         "display": ""
      });
      $("#mm_upload_master_pdtd").css({
         "display": "inline-table",
         "height": $("#pdtd-upload").height() + "px",
         "width": "100%"
      });
   }
}

function loadPdtdHomePageReleases(homePageData) {
   //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
   var homePageLinkList = homePageData.homePageLinkList;
   var homePageDataStr = "";
   if (homePageLinkList != '') {
      var numberOfFolders = 0;
      for (var i = 0; i < homePageLinkList.length; i++) {
         var
            homePageTitleList = homePageLinkList[i].homePageTitleList;
         var
            folderName = homePageLinkList[i].folderName;
         var
            folderName = homePageLinkList[i].folderName.substring(homePageLinkList[i].folderName.indexOf("_") +
               1);
         if (homePageTitleList != '') {
            numberOfFolders++;
            homePageDataStr += "<h4 class='card-title' >" +
               folderName + "<
            h4 > ";
            var
               numberOfTitles = homePageTitleList.length;
            homePageDataStr += "<div class='owl-carousel' id='owl-carousel_" +
               i + "'>";
            for (var
                  j = 0; j < homePageTitleList.length; j++) {
               var
                  homePageTitlesDto = homePageTitleList[j];
               homePageDataStr += "<div class='item' onmouseover=\"
               javascript: this.getElementsByClassName('titleOverlay')[0].style.display = 'inline-flex';\
               "" +
               " onmouseout=\"
               javascript: this.getElementsByClassName('titleOverlay')[0].style.display = 'none';\
               ">"
               homePageDataStr += "<a href='/otmm/ux-html/?p=sammeTitle&title=" +
                  homePageTitlesDto.titleId +
                  "'>";
               console.log("title
                  data: "+JSON.stringify(homePageTitlesDto));
                  if (homePageTitlesDto.screenResObjId == "") {
                     homePageDataStr += "<img alt='image' title='" +
                        homePageTitlesDto.titleName +
                        "' src=\" " + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" +
                        "\"/>";
                  } else {
                     homePageDataStr += "<img alt='image'
                     title = '" + homePageTitlesDto.titleName + "' src = \"/otmmapi/v6/renditions/" + homePageTitlesDto.screenResObjId + "\"/>";
					 //console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);
                  }
                  homePageDataStr += "</a> </div>";

               }

               homePageDataStr += "</div> </br> <input type = 'hidden' name = 'numberOfTitles' value = " +numberOfTitles + " id = 'numberOfTitles' /> ";
            }
         }
         homePageDataStr += "<input type='hidden' name = 'numberOfRelFolders' value = " + numberOfFolders + " id = 'numberOfRelFolders' /> ";
      }
      //console.log("inside homepage js homePageDataStr:"+homePageDataStr);

      /*scroll code*/

      $("#pdtd-home-section").html(homePageDataStr);
      var numTitles = document.getElementById('numberOfTitles').value;
      var scrollwrapperclassvar = "scrollWrapper_0"
      console.log("pdtd numTitles:" + numTitles);
      console.log("scrolleblae:" + $(".scrollableArea"));
      $(".scrollableArea").css("width", "200%");
      $(".pdtd-home-section-div").smoothDivScroll({
         autoScrollingMode: "empty",
         hotSpotScrolling: false,
         manualContinuousScrolling: false,
         mousewheelScrolling: "allDirections",
         scrollWrapperClass: scrollwrapperclassvar,
         touchScrolling: false
      });
      console.log("scrolleblae:" + $(".scrollableArea"));
      $(".scrollableArea").css("width", "200%");
      if (numTitles > 5) {
         $(".scrollWrapper_0").hover(function () {
            var sh = $(this).height() + "px";
            var pt = $(this).position().top + "px";
            var lArrow = $(this).parent().find(".scrollingHotSpotLeft");
            $(lArrow).addClass("scrollingHotSpotLeftVisible");
            $(lArrow).css({
               "display": "block",
               "height": sh,
               "top": pt
            });
            var rArrow = $(this).parent().find(".scrollingHotSpotRight");
            $(rArrow).addClass("scrollingHotSpotRightVisible");
            $(rArrow).css({
               "display": "block",
               "height": sh,
               "top": pt
            })
         });
      } else {
         $(".pdtd-home-section-div").smoothDivScroll("disable");
         $(".scrollableArea").css("width", "200%")
      }
      return homePageDataStr;
   }