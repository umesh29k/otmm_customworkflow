function loadGenericHomePageData(homePageSession)
{
	$("#gen-home").css({"display":"block"});
	$("#home_folder_itm_genre_container").css({"display":"inline-block"});
	var url_gen="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	$.ajax({
		error:function(res){},	
		success:function(res){
		console.log("Res: " + JSON.stringify(res))
			var genHomePage=loadGenHomePageTitles(res);
			$("#gen-home-section").html(genHomePage);
			$(".gen-home-title-hover").each(
					function(){
					var ih=$(this).next().height()+"px";
					var iw=$(this).next().width()+"px";
					$(this).css({"height":ih,"width":iw})});
					$(".ot-homescreen").scroll(function(){
					$(".gen-home-title-hover").each(function(){
					var it=$(this).next().position().top;
				$(this).css({"top":it})
				})})},
				url:url_gen
	});
	$("#mm_upload_master").css({"display":"none"});
	if(otui.UserFETManager.isTokenAvailable("IMPORT")){
		$("#gen-upload").css({"display":""});$("#gen-upload-cell").css({"display":""});
		$("#mm_upload_master_gen").css({"display":"inline-table","height":$("#gen-upload").height()+"px","width":"100%"})
	}
}
function loadGenHomePageTitles(homePageData)
{
	//console.log("inside loadGenHomePageTitles");
	
	var homePageLinkList=homePageData.homePageLinkList;
	 var searchId=homePageData.homePageSearchconfigId;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	   var numberOfFolders=0;
	   for(var i=0;i<homePageLinkList.length;i++)
	   {
		   var homePageTitleList=homePageLinkList[i].homePageTitleList;
		   //var folderName=homePageLinkList[i].folderName;
		  var folderName=homePageLinkList[i].folderName. substring(homePageLinkList[i].folderName.indexOf("_") + 1);
		   if(homePageTitleList!='')
		   {
			    numberOfFolders++;
				homePageDataStr+= "<h4 class='card-title' >"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</h4>";
			
				homePageDataStr+="<div class='owl-carousel' id='owl-carousel_"+i+"'>";
				
				for(var j=0;j<homePageTitleList.length;j++)
				{
					var homePageTitlesDto=homePageTitleList[j];
					homePageDataStr+="<div class='item' onmouseover=\"javascript:this.getElementsByClassName('titleOverlay')[0].style.display='inline-flex';\""
					+ " onmouseout=\"javascript:this.getElementsByClassName('titleOverlay')[0].style.display='none';\">"
					if(homePageTitlesDto.titleId=='999998')
					{						
						homePageDataStr+="<a href=\"javascript:SearchManager.performKeywordSearch('"+homePageTitlesDto.titleId +"||savedSearch||',undefined,undefined,"+searchId+");\">";
						homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" +  				   "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" +"\"/></a><br/><span style='font-family: arial black;'>";
						homePageDataStr+="<br/>"+ homePageTitlesDto.titleName+ "</span>";
					}
					else
					{
						homePageDataStr+="<a href=\"/otmm/ux-html/?p=title&title="+     .titleId +"\">";
						homePageDataStr+= "<div id='titleOverlay_"+j+"' class='titleOverlay' style='display:none'> <div id='titleText'>"+homePageTitlesDto.titleName ;
						homePageDataStr+= " </div></div>";
						if(homePageTitlesDto.screenResObjId==''){
							homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName
										+ "' src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
							}else{
								homePageDataStr+="<img alt='image' title='" + homePageTitlesDto.titleName
									+ "' src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
							}
							homePageDataStr+="</a><span style='font-family: arial black;'>" + homePageTitlesDto.titleName+"</span>"	
					}
				}
		   }
	    }
	}
	return homePageDataStr;
}
