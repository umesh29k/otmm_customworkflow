function loadRepertoryHomepageData(homePageSession) {
   $("#home_genre_search_widget").css({
      "display": "inline"
   });
   $("#repertory-home").css({
      "display": "block"
   });

   var url_repertory_current = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=releases";

   $.ajax({
      url: url_repertory_current,
      success: function (res) {
         var repRes = loadRepertoryHomePageTitles(res);
         $("#repertory-home-section").html(repRes);
      },
      error: function (res) {}
   });

   var url_repertory_features = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=features";

   $.ajax({
      url: url_repertory_features,
      success: function (res) {
         var repRes = getFolderBasedFeatures(res);
         $("#home_folder_repertory_features").html("<div class='repertory_sec_header' style='padding-left: 2%;'>Download(s)</div>" + repRes);
      },
      error: function (res) {}
   });

   if (otui.UserFETManager.isTokenAvailable("IMPORT")) {
      $("#repertory-upload").css({
         "display": ""
      });
      $("#mm_upload_master_repertory").css({
         "display": "inline-table",
         "width": "100%",
         "height": $("#repertory-upload").height() + "px"
      });
   }

}

function loadRepertoryHomePageTitles(homePageData) {
   var homePageLinkList = homePageData.homePageLinkList;
   var homePageDataStr = "";
   if (homePageLinkList != '') {
      var numberOfFolders = 0;
      for (var i = 0; i < homePageLinkList.length; i++) {
         var homePageTitleList = homePageLinkList[i].homePageTitleList;
         //var folderName = homePageLinkList[i].folderName;
		 var folderName = homePageLinkList[i].folderName.substring(homePageLinkList[i].folderName.indexOf("_") + 1);
         if (homePageTitleList != '') {
            numberOfFolders++;
            homePageDataStr += "<h4 class='card-title' >" + folderName + "</h4>";
            homePageDataStr += "<div class='owl-carousel' id='owl-carousel_" + i + "'>";
            for (var j = 0; j < homePageTitleList.length; j++) {
               var homePageTitlesDto = homePageTitleList[j];
               homePageDataStr += "<div class='item'>";
               homePageDataStr += "<a href='/otmm/ux-html/?p=sammeTitle&title=" + homePageTitlesDto.titleId + "'>";
               if (homePageTitlesDto.screenResObjId == '') {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
               } else {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"/otmmapi/v6/renditions/" + homePageTitlesDto.screenResObjId + "\"/>";
               }
               homePageDataStr += "</a></div>";
            }
			homePageDataStr += "</div>";
         }
      }
   }
   return homePageDataStr;
}