function loadInflightHomePageData(homePageSession)
{

	//console.log("inside Inflight homepage");
	$("#arc2session").val(homePageSession.id); 
	$("#arc-home-widgets").css({"display":"none"});
	$("#inflight-home").css({"display":"block"});
	$("#home_folder_inflight_features_container").css({"display":"inline-block"});
	$("#home_folder_inflight_genre_container").css({"display":"inline-block"}); 
	var url_inflight="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	$.ajax(
	{
		error:function(res){},
		success:function(res){
		console.log("Res: " + res)
		loadInflightHomePageReleases(res);
		},
		url:url_inflight
	});
	
	var url_inflight_features = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=features";
	$.ajax({url:url_inflight_features,success:function(res){
		
		homePageDataStr=getFolderBasedFeatures(res);
		if(homePageDataStr.trim()!=='')
		{			
			$("#home_folder_inflight_features").html(homePageDataStr);
		}
		
		//loadInflightHomePageFeatures(res);
	},error:function(res){}});
	
	$("#mm_upload_master").css({"display":"none"});

	if(otui.UserFETManager.isTokenAvailable("IMPORT"))
	{
		$("#inflight-upload-cell").css({"display":"block"});
		$("#inflight-upload").css({"display":""});
		$("#mm_upload_master_inflight").css({"display":"inline-table","width":"100%",
				"height":$("#inflight-upload").height()+"px"});
	}
}	


function loadInflightHomePageReleases(homePageData)
{
  //console.log("inside homepage file method name loadInflightHomePageReleases"+JSON.stringify(homePageData));
  var homePageLinkList=homePageData.homePageLinkList;
  var homePageDataStr="";
  if(homePageLinkList!='')
  {
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   var folderName=homePageLinkList[i].folderName;
	   if(homePageTitleList!='')
	   {
			numberOfFolders++;
			homePageDataStr+= "<tr><td class=\"inflight_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			var numberOfTitles = homePageTitleList.length;
			homePageDataStr+="<tr><td valign=\"top\">";
			homePageDataStr+="<div class=\"inflight-home-section-div_" + i + "\" id=\"inflight-home-section-div_" + i + "\">";
		   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				homePageDataStr+="<div" + " class = \"carousel-tile\"  onmouseover=\"javascript:this.getElementsByClassName('inflight-home-title-hover')[0].style.display='inline-flex';\""
												+ " onmouseout=\"javascript:this.getElementsByClassName('inflight-home-title-hover')[0].style.display='none';\""
												+ " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="
												+ homePageTitlesDto.titleId + "';\">";
				homePageDataStr+="<div class=\"inflight-home-title-hover\">"
										+ "<table width=\"100%\" style=\"height: 100%;\"><tr>" + "<td valign=\"middle\">"
										+ homePageTitlesDto.titleName + "</td>"
										+ "</tr></table></div>"
										
						//console.log("title data:"+JSON.stringify(homePageTitlesDto));			
					if (homePageTitlesDto.screenResObjId=="") 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}
					else 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
									
						//console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
					}
					homePageDataStr+="<br/><span style='font-family: arial black;'>"+homePageTitlesDto.inflightRights
				homePageDataStr+="</span></div>";
		   
		   }
		   
		   homePageDataStr+="</div></td></tr><input type='hidden' name='numberOfTitles_" + i
									+ "' value=" + numberOfTitles + " id='numberOfTitles_" + i + "'/>";
	   }
	}
	homePageDataStr+="<input type='hidden' name='numberOfRelFolders' value="+numberOfFolders+" id='numberOfRelFolders'/>";
	}
	//console.log("inside homepage js homePageDataStr:"+homePageDataStr);
	
	/*scroll code*/
	$("#inflight-home-section").html(homePageDataStr);
     
	var numFolders=document.getElementById('numberOfRelFolders').value;
	for(var i=0;i<numFolders;i+=1){
		var numTitles=document.getElementById('numberOfTitles_'+i).value;
		var scrollwrapperclassvar="scrollWrapper_"+i;
		console.log("Inside loop numTitles:"+numTitles);
		$("#inflight-home-section-div_"+i).smoothDivScroll({
                autoScrollingMode: "empty",
                hotSpotScrolling: false,
                manualContinuousScrolling: false,
                mousewheelScrolling: "allDirections",
		  scrollWrapperClass: scrollwrapperclassvar,
                touchScrolling: false
            });
		$(".scrollableArea").css("width","200%");
		$("."+scrollwrapperclassvar).css({"height":"100%","overflow":"hidden","position":"relative","width":"100%"});
		if(numTitles>3){
			$("."+scrollwrapperclassvar).hover(function(){
			//console.log("**numTitles:"+numTitles);
			var sh=$(this).height()+"px";
			var pt=$(this).position().top+"px";
			var lArrow=$(this).parent().find(".scrollingHotSpotLeft");
			$(lArrow).addClass("scrollingHotSpotLeftVisible");
			$(lArrow).css({"display":"block","height":sh});
			var rArrow=$(this).parent().find(".scrollingHotSpotRight");
			$(rArrow).addClass("scrollingHotSpotRightVisible");
			$(rArrow).css({"display":"block","height":sh})				
			});
		}
		else{
			$(".inflight-home-section-div_"+i).smoothDivScroll("disable");
			$(".scrollableArea").css("width","200%")
		}
	}
	 
	
	return homePageDataStr;
}
