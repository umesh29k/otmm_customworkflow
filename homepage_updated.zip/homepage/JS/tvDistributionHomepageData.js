function loadTVDistributionHomepageData(homePageSession) {
   $("#tv-dist-home").css({
      "display": "block"
   });
   $("#home_folder_tv_dist_container").css({
      "display": "inline-block"
   });
   var url_tv_dist = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=releases";
   $.ajax({
      url: url_tv_dist,
      success: function (res) {

         var tvdistRes = loadTvDistributionHomePageTitles(res);
         $("#home_folder_tv_dist_current_titles").html(tvdistRes);
         $(".tv-dist-home-title-hover").each(
            function () {
               var ih = $(this).next().height() + "px";
               var iw = $(this).next().width() + "px";
               $(this).css({
                  "height": ih,
                  "width": iw
               });
            });
         $(".ot-homescreen").scroll(
            function () {
               $(".tv-dist-home-title-hover").each(function () {
                  var it = $(this).next().position().top;
                  $(this).css({
                     "top": it
                  });
               });
            });
         var hsh = $("#home_folder_tv_dist_container").find(".tv_dist_sec_header").html().trim();
         hsh = hsh + "<span class=\"tv-dist-all-titles\">[ <a href=\"/otmm/ux-html/?p=title\">View All Titles</a> ]</span>";

         $("#home_folder_tv_dist_container").find(".tv_dist_sec_header").html(hsh);
      },
      error: function (res) {}
   });
   if (otui.UserFETManager.isTokenAvailable("IMPORT")) {
      $("#tv-dist-upload-cell").css({
         "display": "block"
      });
      $("#tv-dist-upload").css({
         "display": ""
      });
      $("#mm_upload_master_tv_dist").css({
         "display": "inline-table",
         "width": "100%",
         "height": $("#tv-dist-upload").height() + "px"
      });
   }
}

function loadTvDistributionHomePageTitles(homePageData) {
   var homePageLinkList = homePageData.homePageLinkList;
   var homePageDataStr = "";
   if (homePageLinkList != '') {
      var numberOfFolders = 0;
      for (var i = 0; i < homePageLinkList.length; i++) {
         var homePageTitleList = homePageLinkList[i].homePageTitleList;
         var folderName = homePageLinkList[i].folderName.substring(homePageLinkList[i].folderName.indexOf("_") + 1);
         if (homePageTitleList != '') {
            for (var j = 0; j < homePageTitleList.length; j++) {
               var homePageTitlesDto = homePageTitleList[j];
               numberOfFolders++;
               homePageDataStr += "<h4 class='card-title' >" + folderName + "</h4>";
               homePageDataStr += "<div class='owl-carousel' id='owl-carousel_" + i + "'>";
               homePageDataStr += "<div class='item' " + " onmouseover=\"javascript:this.getElementsByClassName('tv-dist-home-title-hover')[0].style.display='inline-flex';\"" + " onmouseout=\"javascript:this.getElementsByClassName('tv-dist-home-title-hover')[0].style.display='none';\"" + " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title=" + homePageTitlesDto.titleId + "';\">";
			   homePageDataStr += "<a href='/otmm/ux-html/?p=sammeTitle&title=" + homePageTitlesDto.titleId + "'>";
               if (homePageTitlesDto.screenResObjId == '') {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
               } else {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "'  src=\"/otmmapi/v6/renditions/" + homePageTitlesDto.screenResObjId + "\"/>";
               }
               homePageDataStr += "</a></div><div>";
            }
         }
      }
   }
   $("#home_folder_tv_dist_current_titles").html(homePageDataStr);
}