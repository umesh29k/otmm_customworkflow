function loadPheiMarketingHomePageData(homePageSession) {
   $("#phei-mktg-home").css({
      "display": "block"
   });
   $("#home_folder_phei_mktg_features_container").css({
      "display": "inline-block"
   });
   $("#home_folder_phei_mktg_genre_container").css({
      "display": "inline-block"
   });
   var url_phei_mktg = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=releases";

   $.ajax({
      error: function (res) {},
      success: function (res) {
         loadPheiMarketingHomePageReleases(res);
      },
      url: url_phei_mktg
   });

   var url_phei_mktg_features = "/EnterpriseHomePage/homepage?sId=" + homePageSession.id + "&sec=features";
   $.ajax({
         error: function (res) {},
         success: function (res) {

            homePageDataStr = getFolderBasedFeatures(res);
            if (homePageDataStr.trim() !== '') {
               $("#home_folder_phei_mktg_features").html(homePageDataStr);
            }
         },
         url: url_phei_mktg_features
      }
   );

   $("#mm_upload_master").css({
      "display": "none"
   });
   //console.log("import:"+otui.UserFETManager.isTokenAvailable("IMPORT"));
   if (otui.UserFETManager.isTokenAvailable("IMPORT")) {

      $("#phei-mktg-upload-cell").css({
         "display": "block"
      });
      $("#phei-mktg-upload").css({
         "display": ""
      });
      $("#mm_upload_master_phei_mktg").css({
         "display": "inline-table",
         "height": $("#phei-mktg-upload").height() + "px",
         "width": "100%"
      })

   }

}

function loadPheiMarketingHomePageReleases(homePageData) {
   //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
   var homePageLinkList = homePageData.homePageLinkList;
   var homePageDataStr = "";
   if (homePageLinkList != '') {
      var numberOfFolders = 0;
      for (var i = 0; i < homePageLinkList.length; i++) {
         var homePageTitleList = homePageLinkList[i].homePageTitleList;
         var folderName = homePageLinkList[i].folderName;
         if (homePageTitleList != '') {
            numberOfFolders++;
            homePageDataStr += "<h4 class='card-title' >" +
               folderName.substring(folderName.indexOf("_") + 1) + "</h4>";
            var numberOfTitles = homePageTitleList.length;
            homePageDataStr += "<div class='owl-carousel' id='owl-carousel_" + i + "'>";
            for (var j = 0; j < homePageTitleList.length; j++) {
               var homePageTitlesDto = homePageTitleList[j];
               homePageDataStr += "<div class='item' onmouseover=\"javascript:this.getElementsByClassName('phei-mktg-home-title-hover')[0].style.display='inline-flex';\"" + " onmouseout=\"javascript:this.getElementsByClassName('phei-mktg-home-title-hover')[0].style.display='none';\"" + " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title=" + homePageTitlesDto.titleId + "';\">";
			   homePageDataStr += "<a href='/otmm/ux-html/?p=sammeTitle&title=" + homePageTitlesDto.titleId + "'>";
               //console.log("title data:"+JSON.stringify(homePageTitlesDto));			
               if (homePageTitlesDto.screenResObjId == "" || homePageTitlesDto.screenResObjId == null) {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"" + "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
               } else {
                  homePageDataStr += "<img alt='image' title='" + homePageTitlesDto.titleName + "' src=\"/otmmapi/v6/renditions/" + homePageTitlesDto.screenResObjId + "\"/>"; //console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
               }
               homePageDataStr += "</a></div>";
            }
            homePageDataStr += "</div></br><input type='hidden' name='numberOfTitles' value=" + numberOfTitles + " id='numberOfTitles'/>";
         }
      }
      homePageDataStr += "<input type='hidden' name='numberOfRelFolders' value=" + numberOfFolders + " id='numberOfRelFolders'/>";
   }
   //console.log("inside homepage js homePageDataStr:"+homePageDataStr);


   $("#phei-mktg-home-section").html(homePageDataStr);
   var numTitles = document.getElementById('numberOfTitles').value;
   console.log("numTitles:" + numTitles);
   var scrollwrapperclassvar = "scrollWrapper_0";
   $(".phei-mktg-home-section-div").smoothDivScroll({
      autoScrollingMode: "empty",
      hotSpotScrolling: false,
      manualContinuousScrolling: false,
      mousewheelScrolling: "allDirections",
      scrollWrapperClass: scrollwrapperclassvar,
      touchScrolling: false
   });
   $(".scrollableArea").css("width", "200%");
   if (numTitles > 5) {
      $(".scrollWrapper_0").hover(function () {
         var sh = $(this).height() + "px";
         var pt = $(this).position().top + "px";
         var lArrow = $(this).parent().find(".scrollingHotSpotLeft");
         $(lArrow).addClass("scrollingHotSpotLeftVisible");
         $(lArrow).css({
            "display": "block",
            "height": sh,
            "top": pt
         });
         var rArrow = $(this).parent().find(".scrollingHotSpotRight");
         $(rArrow).addClass("scrollingHotSpotRightVisible");
         $(rArrow).css({
            "display": "block",
            "height": sh,
            "top": pt
         })
      });
   } else {
      $(".phei-mktg-home-section-div").smoothDivScroll("disable");
      $(".scrollableArea").css("width", "200%")
   }
}