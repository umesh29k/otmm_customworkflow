funcion smoothDivScroll(){

	$(".scrollableArea").on("mouseenter",function(){
		$(this).find('span')[0].style.display='inline-flex';
	});
	$(".scrollableArea").on("mouseleave",function(){
		$(this).find('span')[0].style.display='none';
	});
	//grab the width and calculate left value
	var item_width = $('.scrollableArea').outerWidth(); 
	var left_value = item_width * (-1); 
	console.log("left_value:" +left_value);
        
    //move the last item before first item, just in case user click prev button
	//$('#slides li:first').before($('.scrollableArea:last'));
	
	//set the default item to the correct position 
	//$('.scrollableArea').css({'left' : left_value});

    //if user clicked on prev button
	$('.scrollingHotSpotRight').click(function() {

		//get the right position            
		var left_indent = parseInt($('.scrollableArea').css('left')) + item_width;

		//slide the item            
		$('.scrollableArea').animate({'left' : 0}, 1, function(){    

            //move the last item and put it as first item            	
			
			$('.scrollableArea:first').before($('.scrollableArea:last'));

			//set the default item to correct position
			//$('.scrollableArea').css({'left' : 0});

		});

		//cancel the link behavior            
		return false;
            
	});

 
    //if user clicked on next button
	$('.scrollingHotSpotLeft').click(function() {
		
		//get the right position
		var left_indent = parseInt($('.scrollableArea').css('left')) - item_width;
		
		//slide the item
		$('.scrollableArea').animate({'left' : 0}, 1,  function () {

            //move the first item and put it as last item
			$('.scrollableArea:last').after($('.scrollableArea:first'));
			                 	

			//set the default item to correct position
			//$('.scrollableArea').css({'left' : 0});

		});
		         
		//cancel the link behavior
		return false;
		
	});
}