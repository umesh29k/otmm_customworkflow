otui.ready(function(){
function getParameterByName(name) {
			name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
			var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
				results = regex.exec(location.search);
			return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
		}
              
function getPreferedSysId(sessionId) {
	var urlsys = "/EnterpriseAdminConfig/prefSystem?sId="+sessionId;
	var sysId = "0";
	$.ajax({url:urlsys,success:function(res){
		sysId = res;
	}});
	return sysId;
}
});
/*	function loadVaultHomePageData(homePageSession)
{	
	$("#phei-home").css({"display":"table"});
	$("#home_folder_phei_features_container").css({"display":"inline-block"});
	$("#home_folder_phei_genre_container").css({"display":"inline-block"});
	var url_phei="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	
	$.ajax({
		error:function(res){},
		success:function(res){
			loadVaultHomePageTitles(res);
			}
			,url:url_phei
			})			
	
	var url_phei_features="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=features";
	$.ajax({error:function(res){},success:function(res){
		
		var vaultRes=loadVaultHomePageFeatures(res);
		$("#home_folder_phei_features").html(vaultRes);
	  
	  },url:url_phei_features});

	if(otui.UserFETManager.isTokenAvailable("IMPORT"))
		{
			$("#phei-upload-cell").css({"display":"block"});
			$("#phei-upload").css({"display":""});
			$("#mm_upload_master_phei").css({"display":"inline-table","width":"100%","height":$("#phei-upload").height()+"px"});
		}
}
*/
/*function  loadVaultHomePageFeatures(homePageData)
{	
		var roleName=(JSON.parse(sessionStorage.session)).role_name;
		var vaultRes=getFolderBasedFeatures(homePageData);
		var query = window.location;
		//vaultRes=vaultRes+"<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition':[{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'ARTESIA.FIELD.DATE IMPORTED','relational_operator_id': 'ARTESIA.OPERATOR.DATE.IS YESTERDAY','value': ''},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '12','left_paren':'(','relational_operator': 'and'},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '17','relational_operator': 'or','right_paren':')'}]}, 'ARTESIA.FIELD.DATE IMPORTED','desc', 'en_US','3','Metadata and File Content');\">Uploads last 24 hours</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI MAT NUMBER','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '*0*'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">MAT Assets</div>";
	    if (query.host == "enterprise.viacomcbs.com" || query.host == "enterpriseuat.viacomcbs.com" || query.host == "10.224.79.142:11090")
		{
			vaultRes=vaultRes+"<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition':[{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'ARTESIA.FIELD.DATE IMPORTED','relational_operator_id': 'ARTESIA.OPERATOR.DATE.IS YESTERDAY','value': ''},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '12','left_paren':'(','relational_operator': 'and'},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '17','relational_operator': 'or','right_paren':')'}]}, 'ARTESIA.FIELD.DATE IMPORTED','desc', 'en_US','3','Metadata and File Content');\">Uploads last 24 hours</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '44','left_paren': '(','relational_operator': 'and'}, {'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '45','right_paren': ')','relational_operator': 'or'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '13','relational_operator': 'and'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Templates</div>";

			if(roleName.toLowerCase()=='phei admin')
				{
					vaultRes=vaultRes+"<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1247', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.STATUS','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '8'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Deleted Assets</div>";
				}

		vaultRes=vaultRes+"<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1227', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI MAT NUMBER','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '*0*'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">MAT Assets</div>";
		}
	    else if(query.host == "10.224.5.113:11090")
		{
			vaultRes=vaultRes+"<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition':[{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'ARTESIA.FIELD.DATE IMPORTED','relational_operator_id': 'ARTESIA.OPERATOR.DATE.IS YESTERDAY','value': ''},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '12','left_paren':'(','relational_operator': 'and'},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '17','relational_operator': 'or','right_paren':')'}]}, 'ARTESIA.FIELD.DATE IMPORTED','desc', 'en_US','3','Metadata and File Content');\">Uploads last 24 hours</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '44','left_paren': '(','relational_operator': 'and'}, {'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PRODUCT','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '45','right_paren': ')','relational_operator': 'or'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchTabularCondition','metadata_table_id': 'CUSTOM.FIELD.ASSET TERRITORY','tabular_field_list': [{'type': 'com.artesia.search.SearchTabularFieldCondition','metadata_field_id': 'TERRITORY.ID','relational_operator_id': 'ARTESIA.OPERATOR.NUMBER.IS','value': '116'}]},{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI CATEGORY','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '13','relational_operator': 'and'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Templates</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'683', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.STATUS','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '8'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Deleted Assets</div><div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'581', 'Home Media International Assets', {'search_condition': [{'type': 'com.artesia.search.SearchScalarCondition','metadata_field_id': 'CUSTOM.FIELD.PHEI MAT NUMBER','relational_operator_id': 'ARTESIA.OPERATOR.CHAR.CONTAINS','value': '*0*'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">MAT Assets</div>";
		}
		return vaultRes;
}
*/
/*function loadVaultHomePageTitles(homePageData)
{	
  //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
  var homePageLinkList=homePageData.homePageLinkList;
  var homePageDataStr="";
  if(homePageLinkList!='')
  {
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   var folderName=homePageLinkList[i].folderName;
	   if(homePageTitleList!='')
	   {
			numberOfFolders++;
			homePageDataStr+= "<tr><td class=\"phei_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			var numberOfTitles = homePageTitleList.length;
			homePageDataStr+="<tr><td valign=\"top\">";
			
			homePageDataStr+="<div class=\"phei-home-section-div\">";
		   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				homePageDataStr+="<div" + " class = \"carousel-tile\"  onmouseover=\"javascript:this.getElementsByClassName('phei-home-title-hover')[0].style.display='inline-flex';\""
												+ " onmouseout=\"javascript:this.getElementsByClassName('phei-home-title-hover')[0].style.display='none';\""
												+ " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="
												+ homePageTitlesDto.titleId + "';\">";
				homePageDataStr+="<div class=\"phei-home-title-hover\">"
										+ "<table width=\"100%\" style=\"height: 100%;\"><tr>" + "<td valign=\"middle\">"
										+ homePageTitlesDto.titleName + "</td>"
										+ "</tr></table></div>"
										
						//console.log("title data:"+JSON.stringify(homePageTitlesDto));			
					if (homePageTitlesDto.screenResObjId=="") 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}
					else 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
									
						//console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
					}
				homePageDataStr+="</div>";
		   
		   }
		   
		   homePageDataStr+="</div></td></tr><input type='hidden' name='numberOfTitles' value="+numberOfTitles+" id='numberOfTitles'/>";
	   }
	}
	homePageDataStr+="<input type='hidden' name='numberOfRelFolders' value="+numberOfFolders+" id='numberOfRelFolders'/>";
	}
	//console.log("inside homepage js homePageDataStr:"+homePageDataStr);
	
	
	$("#phei-home-section").html(homePageDataStr);
	
	var numTitles=document.getElementById('numberOfTitles').value;
	var scrollwrapperclassvar = "scrollWrapper_0";

	$(".scrollableArea").css("width","200%");
	$(".phei-home-section-div").smoothDivScroll({
                autoScrollingMode: "empty",
                hotSpotScrolling: false,
                manualContinuousScrolling: false,
                mousewheelScrolling: "allDirections",
      		  scrollWrapperClass: scrollwrapperclassvar,
                touchScrolling: false});
	
	$(".scrollableArea").css("width","200%");
	if(numTitles>5)
	{
		$(".scrollWrapper_0").hover(
		function(){
			var sh=$(this).height()+"px";
			var pt=$(this).position().top+"px";
			var lArrow=$(this).parent().find(".scrollingHotSpotLeft");
			$(lArrow).addClass("scrollingHotSpotLeftVisible");
			$(lArrow).css({"display":"block","height":sh,"top":pt});
			var rArrow=$(this).parent().find(".scrollingHotSpotRight");
			$(rArrow).addClass("scrollingHotSpotRightVisible");
			$(rArrow).css({"display":"block","height":sh,"top":pt})
			});
	}			
	else
	{
		$(".phei-home-section-div").smoothDivScroll("disable");
		$(".scrollableArea").css("width","200%")
	}
}*/
/*
function loadGenericHomePageData(homePageSession)
{
	$("#gen-home").css({"display":"block"});
	$("#home_folder_itm_genre_container").css({"display":"inline-block"});
	var url_gen="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	$.ajax({
		error:function(res){},	
		success:function(res){
		var genHomePage=loadGenHomePageTitles(res);
		$("#gen-home-section").html(genHomePage);
		$(".gen-home-title-hover").each(
						function(){
						var ih=$(this).next().height()+"px";
						var iw=$(this).next().width()+"px";
						$(this).css({"height":ih,"width":iw})});
						$(".ot-homescreen").scroll(function(){
						$(".gen-home-title-hover").each(function(){
						var it=$(this).next().position().top;
					$(this).css({"top":it})
					})})},
					url:url_gen
					});
					
		$("#mm_upload_master").css({"display":"none"});
		if(otui.UserFETManager.isTokenAvailable("IMPORT")){
			$("#gen-upload").css({"display":""});$("#gen-upload-cell").css({"display":""});
			$("#mm_upload_master_gen").css({"display":"inline-table","height":$("#gen-upload").height()+"px","width":"100%"})
			}
	
	
}
function loadGenHomePageTitles(homePageData)
{
	//console.log("inside loadGenHomePageTitles");
	
	var homePageLinkList=homePageData.homePageLinkList;
	 var searchId=homePageData.homePageSearchconfigId;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	    var numberOfFolders=0;
	   for(var i=0;i<homePageLinkList.length;i++)
	   {
		   var homePageTitleList=homePageLinkList[i].homePageTitleList;
		   var folderName=homePageLinkList[i].folderName;
		  
		   if(homePageTitleList!='')
		   {
				homePageDataStr+= "<tr><td class=\"gen_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			
				homePageDataStr+="<tr><td valign=\"top\"><div class=\"gen-home-section-div\">";
				
				for(var j=0;j<homePageTitleList.length;j++)
				{
					var homePageTitlesDto=homePageTitleList[j];
					if(homePageTitlesDto.titleId=='999998')
					{						
						homePageDataStr+="<div>";
						homePageDataStr+="<a style=\"color:#232e72;cursor: pointer;text-decoration: none;\" "+
										"href=\"javascript:SearchManager.performKeywordSearch('"+homePageTitlesDto.titleId +
										"||savedSearch||',undefined,undefined,"+searchId+");\">";
						
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName + "\" style=\"border: none;\" width=\"80%\" src=\""+  				   "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" +"\"/>";
						homePageDataStr+="<br/>"+ homePageTitlesDto.titleName+ "</a></div>";
						
					}
					else
					{
						homePageDataStr+="<div>";
						homePageDataStr+="<a style=\"color:#232e72;cursor: pointer;text-decoration: none;\" " +
								"href=\"/otmm/ux-html/?p=title&title="+ homePageTitlesDto.titleId +"\">";
						if(homePageTitlesDto.screenResObjId==''){
															
							homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
							}else{
								homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
							}
							homePageDataStr+="<br/>" + homePageTitlesDto.titleName+"</a></div>";							
						
					}
					
					
				}				
			   
		   }
	    }
	}
	return homePageDataStr;
}
*/
/*
function loadItmHomePageData(homePageSession)
{	

	$("#itm-home").css({"display":"inline-table"});
	$("#home_folder_itm_genre_container").css({"display":"inline-block"});
	var url_itm_current="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases"; 
	$.ajax({
		url:url_itm_current,
		success:function(res){
			
			var itmHomepage=loadItmHomePageTitles(res);
			$("#itm-home-section").html(itmHomepage);
			$(".itm-home-title-hover").each(
			function(){var ih=$(this).next().height()+"px";
			var iw=$(this).next().width()+"px"; 
			$(this).css({"height":ih,"width":iw});
			});
			
			$(".ot-homescreen").scroll(function(){$(".itm-home-title-hover").each(function(){var it=$(this).next().position().top;$(this).css({"top":it});});});
			},
			error:function(res){}
			});
			
	$("#mm_upload_master").css({"display":"none"});
	if(otui.UserFETManager.isTokenAvailable("IMPORT")){
		$("#itm-upload").css({"display":""});
		$("#itm-upload-cell").css({"display":""});
		$("#mm_upload_master_itm").css({"display":"inline-table","width":"100%","height":$("#itm-upload").height()+"px"});
		}		
	
}

function loadItmHomePageTitles(homePageData)
{
	
	var homePageLinkList=homePageData.homePageLinkList;
	 var searchId=homePageData.homePageSearchconfigId;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	    var numberOfFolders=0;
	   for(var i=0;i<homePageLinkList.length;i++)
	   {
		   var homePageTitleList=homePageLinkList[i].homePageTitleList;
		   var folderName=homePageLinkList[i].folderName;
		  
		   if(homePageTitleList!='')
		   {
				homePageDataStr+= "<tr><td class=\"itm_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			
				homePageDataStr+="<tr><td valign=\"top\"><div class=\"itm-home-section-div\">";
				
				for(var j=0;j<homePageTitleList.length;j++)
				{
					var homePageTitlesDto=homePageTitleList[j];
					if(homePageTitlesDto.titleId=='999998')
					{						
						homePageDataStr+="<div>";
						homePageDataStr+="<a style=\"color:#232e72;cursor: pointer;text-decoration: none;\" "+
										"href=\"javascript:SearchManager.performKeywordSearch('"+homePageTitlesDto.titleId +
										"||savedSearch||',undefined,undefined,"+searchId+");\">";
						
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName + "\" style=\"border: none;\" width=\"80%\" src=\""+  				   "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" +"\"/>";
						homePageDataStr+="<br/>"+ homePageTitlesDto.titleName+ "</a></div>";
						
					}
					else
					{
						homePageDataStr+="<div>";
						homePageDataStr+="<a style=\"color:#0072AA;cursor: pointer;text-decoration: none;\" " +
								"href=\"/otmm/ux-html/?p=title&title="+ homePageTitlesDto.titleId +"\">";
						if(homePageTitlesDto.screenResObjId==''){
															
							homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
							}else{
								homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
							}
							homePageDataStr+="<br/>" + homePageTitlesDto.titleName+"</a></div>";							
						
					}
					
					
				}				
			   
		   }
	    }
	}
	return homePageDataStr;
}
*/
/*
function loadRepertoryHomepageData(homePageSession)
{
	
	$("#home_genre_search_widget").css({"display":"inline"});
	$("#repertory-home").css({"display":"block"});
	
	var url_repertory_current = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases"; 
	
	$.ajax({
			url:url_repertory_current,
			success:function(res){
			var repRes=loadRepertoryHomePageTitles(res);
			$("#repertory-home-section").html(repRes);
			},
		error:function(res){}
		});
	
	
	
	var url_repertory_features = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=features"; 
	
	$.ajax({
		url:url_repertory_features,
		success:function(res){
			var repRes=getFolderBasedFeatures(res);
			$("#home_folder_repertory_features").html("<div class='repertory_sec_header' style='padding-left: 2%;'>Download(s)</div>"+repRes);
			
			
			},
			error:function(res){}}
			); 
			
		 
			
	    if(otui.UserFETManager.isTokenAvailable("IMPORT")){
			$("#repertory-upload").css({"display":""});
			$("#mm_upload_master_repertory").css({"display":"inline-table","width":"100%","height":$("#repertory-upload").height()+"px"});
			}
	
	
}

function loadRepertoryHomePageTitles(homePageData)
{
	var homePageLinkList=homePageData.homePageLinkList;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   var folderName=homePageLinkList[i].folderName;
	   if(homePageTitleList!='')
	   {
			numberOfFolders++;
			homePageDataStr+= "<tr><td class=\"repertory_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			
			homePageDataStr+="<tr><td valign=\"top\"><div class=\"repertory-home-section-div\">";			
		   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				
				homePageDataStr+="<div>";
				homePageDataStr+="<a style=\"color:#0072AA;cursor: pointer;text-decoration: none;\" " +
								"href=\"/otmm/ux-html/?p=title&title="+ homePageTitlesDto.titleId +"\">";
				if(homePageTitlesDto.screenResObjId==''){
															
					homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
				}else{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
				}
				homePageDataStr+="</div>";				
		   }
	   }
	}
  }	
	return homePageDataStr;
}
*/
/*
function loadPressKitHomepageData(homePageSession)
{
	$("#presskit-home").css({"display":"table"});
	$("#home_folder_presskit_container").css({"display":"inline-block"});
	
	
	var url_pk = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=''";
	$.ajax({url:url_pk,success:function(res){
		var homePageDataStr=loadPresskitHomePageTitles(res);
		$("#home_folder_presskit_current_titles").html(homePageDataStr);
		$(".presskit-home-title-hover").each(function(){
			var ih=$(this).next().height()+"px";
			var iw=$(this).next().width()+"px";
			$(this).css({"height":ih,"width":iw});});
			$(".ot-homescreen").scroll(function(){
				$(".presskit-home-title-hover").each(function(){
					var it=$(this).next().position().top;$(this).css({"top":it});});
					});
			var hsh=$("#home_folder_presskit_container").find(".presskit_sec_header").html().trim();
			hsh=hsh+"<span class=\"presskit-all-titles\">[&nbsp;<a href=\"/otmm/ux-html/?p=title\">View All Titles</a>&nbsp;]</span>";$("#home_folder_presskit_container").find(".presskit_sec_header").html(hsh);
			},
			error:function(res){}
			});
		if(otui.UserFETManager.isTokenAvailable("IMPORT")){
			$("#presskit-upload-cell").css({"display":"block"});
			$("#presskit-upload").css({"display":""});
			$("#mm_upload_master_presskit").css({"display":"inline-table","width":"100%","height":$("#presskit-upload").height()+"px"});
			}
	
}

function loadPresskitHomePageTitles(homePageData)
{

	var homePageLinkList=homePageData.homePageLinkList;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   
	   if(homePageTitleList!='')
	   {
	   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				
				homePageDataStr+="<div " +
									" onmouseover=\"javascript:this.getElementsByClassName('presskit-home-title-hover')[0].style.display='inline-flex';\"" +
									" onmouseout=\"javascript:this.getElementsByClassName('presskit-home-title-hover')[0].style.display='none';\"" +
									" onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="+homePageTitlesDto.titleId+"';\">";
				homePageDataStr+="<div class=\"presskit-home-title-hover\">" +
									"<table width=\"100%\" style=\"height: 100%;\"><tr>" +
									"<td valign=\"middle\">"+homePageTitlesDto.titleName +"</td>" +
									"</tr></table></div>";
				if(homePageTitlesDto.presskitThumbUoiId =='' || homePageTitlesDto.presskitThumbUoiId == null){
															
								homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
				}else{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.presskitThumbUoiId+ "\"/>";
				}
							homePageDataStr+="</div>";
		   
		   }
	   }
	}
	}
	return homePageDataStr;
	//$("#home_folder_lic_current_titles").html(homePageDataStr);

}
*/
/*
function loadTVDistributionHomepageData(homePageSession)
{
	
	$("#tv-dist-home").css({"display":"table"});
	$("#home_folder_tv_dist_container").css({"display":"inline-block"});
	
	
	var url_tv_dist = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	$.ajax({
			url:url_tv_dist,
			success:function(res)
			{
				
				var tvdistRes=loadTvDistributionHomePageTitles(res);
				$("#home_folder_tv_dist_current_titles").html(tvdistRes);
				$(".tv-dist-home-title-hover").each(
				function(){
						var ih=$(this).next().height()+"px";
						var iw=$(this).next().width()+"px";
						$(this).css({"height":ih,"width":iw});
					});
					
				$(".ot-homescreen").scroll(
					function(){	
							$(".tv-dist-home-title-hover").each(function(){var it=$(this).next().position().top;$(this).css({"top":it});});
							});
					
				var hsh=$("#home_folder_tv_dist_container").find(".tv_dist_sec_header").html().trim();
				hsh=hsh+"<span class=\"tv-dist-all-titles\">[&nbsp;<a href=\"/otmm/ux-html/?p=title\">View All Titles</a>&nbsp;]</span>";
				
				$("#home_folder_tv_dist_container").find(".tv_dist_sec_header").html(hsh);
			},
			error:function(res){}
		});
		if(otui.UserFETManager.isTokenAvailable("IMPORT"))
		{
			$("#tv-dist-upload-cell").css({"display":"block"});
			$("#tv-dist-upload").css({"display":""});
			$("#mm_upload_master_tv_dist").css({"display":"inline-table","width":"100%","height":$("#tv-dist-upload").height()+"px"});
		}
	
	
}

function loadTvDistributionHomePageTitles(homePageData)
{

	var homePageLinkList=homePageData.homePageLinkList;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   
	   if(homePageTitleList!='')
	   {
	   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				
				homePageDataStr+="<div " +
									" onmouseover=\"javascript:this.getElementsByClassName('tv-dist-home-title-hover')[0].style.display='inline-flex';\"" +
									" onmouseout=\"javascript:this.getElementsByClassName('tv-dist-home-title-hover')[0].style.display='none';\"" +
									" onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="+homePageTitlesDto.titleId+"';\">";
				homePageDataStr+="<div class=\"tv-dist-home-title-hover\">" +
									"<table width=\"100%\" style=\"height: 100%;\"><tr>" +
									"<td valign=\"middle\">"+homePageTitlesDto.titleName +"</td>" +
									"</tr></table></div>";
				if(homePageTitlesDto.screenResObjId==''){
															
								homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
				}else{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
				}
							homePageDataStr+="</div>";
		   
		   }
	   }
	}
	}
	$("#home_folder_tv_dist_current_titles").html(homePageDataStr);

}
*/
/*
function loadPheiMarketingHomePageData(homePageSession)
{
	
	$("#phei-mktg-home").css({"display":"table"});
	$("#home_folder_phei_mktg_features_container").css({"display":"inline-block"});
	$("#home_folder_phei_mktg_genre_container").css({"display":"inline-block"});
	var url_phei_mktg="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	
	$.ajax({
		error:function(res){},
		success:function(res){	
		loadPheiMarketingHomePageReleases(res);
		},
		url:url_phei_mktg
		});
	
	var url_phei_mktg_features="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=features";
	$.ajax({
		error:function(res){},
		success:function(res){
			
				homePageDataStr=getFolderBasedFeatures(res);
				if(homePageDataStr.trim()!=='')
				{			
					$("#home_folder_phei_mktg_features").html(homePageDataStr);
				}			
				
			
				
			},url:url_phei_mktg_features}
				
				);
	
	$("#mm_upload_master").css({"display":"none"});
	//console.log("import:"+otui.UserFETManager.isTokenAvailable("IMPORT"));
	if(otui.UserFETManager.isTokenAvailable("IMPORT")){
	
		$("#phei-mktg-upload-cell").css({"display":"block"});
		$("#phei-mktg-upload").css({"display":""});
		$("#mm_upload_master_phei_mktg").css({"display":"inline-table","height":$("#phei-mktg-upload").height()+"px","width":"100%"})
	
	}
	
}

function loadPheiMarketingHomePageReleases(homePageData)
{		
	
  //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
  var homePageLinkList=homePageData.homePageLinkList;
  var homePageDataStr="";
  if(homePageLinkList!='')
  {
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   var folderName=homePageLinkList[i].folderName;
	   if(homePageTitleList!='')
	   {
			numberOfFolders++;
			homePageDataStr+= "<tr><td class=\"phei_mktg_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			var numberOfTitles = homePageTitleList.length;
			homePageDataStr+="<tr><td valign=\"top\">";
			
			homePageDataStr+="<div class=\"phei-mktg-home-section-div\">";
		   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				homePageDataStr+="<div" + " class = \"carousel-tile\" onmouseover=\"javascript:this.getElementsByClassName('phei-mktg-home-title-hover')[0].style.display='inline-flex';\""
												+ " onmouseout=\"javascript:this.getElementsByClassName('phei-mktg-home-title-hover')[0].style.display='none';\""
												+ " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="
												+ homePageTitlesDto.titleId + "';\">";
				homePageDataStr+="<div class=\"phei-mktg-home-title-hover\">"
										+ "<table width=\"100%\" style=\"height: 100%;\"><tr>" + "<td valign=\"middle\">"
										+ homePageTitlesDto.titleName + "</td>"
										+ "</tr></table></div>"
										
						//console.log("title data:"+JSON.stringify(homePageTitlesDto));			
					if (homePageTitlesDto.screenResObjId=="" || homePageTitlesDto.screenResObjId == null) 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}
					else 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
									
						//console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
					}
				homePageDataStr+="</div>";
		   
		   }
		   
		   homePageDataStr+="</div></td></tr><input type='hidden' name='numberOfTitles' value="+numberOfTitles+" id='numberOfTitles'/>";
	   }
	}
	homePageDataStr+="<input type='hidden' name='numberOfRelFolders' value="+numberOfFolders+" id='numberOfRelFolders'/>";
	}
	//console.log("inside homepage js homePageDataStr:"+homePageDataStr);
	
	
	$("#phei-mktg-home-section").html(homePageDataStr);
	var numTitles=document.getElementById('numberOfTitles').value;
	console.log("numTitles:"+numTitles);
	var scrollwrapperclassvar = "scrollWrapper_0";
	$(".phei-mktg-home-section-div").smoothDivScroll({autoScrollingMode: "empty",
                hotSpotScrolling: false,
                manualContinuousScrolling: false,
                mousewheelScrolling: "allDirections",	
      		  scrollWrapperClass: scrollwrapperclassvar,
                touchScrolling: false
	});	
	$(".scrollableArea").css("width","200%");
	if(numTitles>5)
	{
		$(".scrollWrapper_0").hover(function(){
		var sh=$(this).height()+"px";
		var pt=$(this).position().top+"px";
		var lArrow=$(this).parent().find(".scrollingHotSpotLeft");
			$(lArrow).addClass("scrollingHotSpotLeftVisible");
			$(lArrow).css({"display":"block","height":sh,"top":pt});
		var rArrow=$(this).parent().find(".scrollingHotSpotRight");
			$(rArrow).addClass("scrollingHotSpotRightVisible");
			$(rArrow).css({"display":"block","height":sh,"top":pt})
			});
	}
else{
		$(".phei-mktg-home-section-div").smoothDivScroll("disable");
		$(".scrollableArea").css("width","200%")
	}

	
}	
*/
/*
function loadPdtdHomePageData(homePageSession)
{

	$("#arc2session").val(homePageSession.id);
	$("#arc-home-widgets").css({"display":"none"});
	$("#pdtd-home").css({"display":"table"});
	$("#home_folder_pdtd_features_container").css({"display":"inline-block"});
	$("#home_folder_pdtd_genre_container").css({"display":"inline-block"});
	var url_pdtd="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";

	$.ajax({error:function(res){},success:function(res){
	//console.log("res:"+res);
	loadPdtdHomePageReleases(res);

	},
	url:url_pdtd
	}
	);

	var url_pdtd_mktg_features="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=features";
	$.ajax({error:function(res){},success:function(res){if(res!=null){$("#home_folder_pdtd_features_container").css({"display":"inline-block"});$("#home_folder_pdtd_features").html(res)}},url:url_pdtd_mktg_features});

	$("#mm_upload_master").css({"display":"none"});
	//console.log("import:"+otui.UserFETManager.isTokenAvailable("IMPORT"));
	if(otui.UserFETManager.isTokenAvailable("IMPORT"))
	{
		$("#pdtd-upload-cell1").css({"display":"block"});
		$("#pdtd-upload").css({"display":""});
		$("#mm_upload_master_pdtd").css({"display":"inline-table",
			"height":$("#pdtd-upload").height()+"px","width":"100%"});
											
	}





}

function loadPdtdHomePageReleases(homePageData)
{
  //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
  var homePageLinkList=homePageData.homePageLinkList;
  var homePageDataStr="";
  if(homePageLinkList!='')
  {
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   var folderName=homePageLinkList[i].folderName;
	   if(homePageTitleList!='')
	   {
			numberOfFolders++;
			homePageDataStr+= "<tr><td class=\"pdtd_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			var numberOfTitles = homePageTitleList.length;
			homePageDataStr+="<tr><td valign=\"top\">";
			
			homePageDataStr+="<div class=\"pdtd-home-section-div\">";
		   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				homePageDataStr+="<div" + " class = \"carousel-tile\" onmouseover=\"javascript:this.getElementsByClassName('pdtd-home-title-hover')[0].style.display='inline-flex';\""
												+ " onmouseout=\"javascript:this.getElementsByClassName('pdtd-home-title-hover')[0].style.display='none';\""
												+ " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="
												+ homePageTitlesDto.titleId + "';\">";
				homePageDataStr+="<div class=\"pdtd-home-title-hover\">"
										+ "<table width=\"100%\" style=\"height: 100%;\"><tr>" + "<td valign=\"middle\">"
										+ homePageTitlesDto.titleName + "</td>"
										+ "</tr></table></div>"
										
						//console.log("title data:"+JSON.stringify(homePageTitlesDto));			
					if (homePageTitlesDto.screenResObjId=="") 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}
					else 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
									
						//console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
					}
				homePageDataStr+="</div>";
		   
		   }
		   
		   homePageDataStr+="</div></td></tr><input type='hidden' name='numberOfTitles' value="+numberOfTitles+" id='numberOfTitles'/>";
	   }
	}
	homePageDataStr+="<input type='hidden' name='numberOfRelFolders' value="+numberOfFolders+" id='numberOfRelFolders'/>";
	}
	//console.log("inside homepage js homePageDataStr:"+homePageDataStr);
	
	//scroll code
	
	$("#pdtd-home-section").html(homePageDataStr);
        var numTitles=document.getElementById('numberOfTitles').value;
	var scrollwrapperclassvar = "scrollWrapper_0"
console.log("pdtd numTitles:"+numTitles);
console.log("scrolleblae:"+$(".scrollableArea"));
$(".scrollableArea").css("width","200%");
$(".pdtd-home-section-div").smoothDivScroll({
                autoScrollingMode: "empty",
                hotSpotScrolling: false,
                manualContinuousScrolling: false,
                mousewheelScrolling: "allDirections",
		  scrollWrapperClass: scrollwrapperclassvar,
                touchScrolling: false
            });
console.log("scrolleblae:"+$(".scrollableArea"));$(".scrollableArea").css("width","200%");
if(numTitles>5){
$(".scrollWrapper_0").hover(function(){
var sh=$(this).height()+"px";
var pt=$(this).position().top+"px";
var lArrow=$(this).parent().find(".scrollingHotSpotLeft");
$(lArrow).addClass("scrollingHotSpotLeftVisible");
$(lArrow).css({"display":"block","height":sh,"top":pt});
var rArrow=$(this).parent().find(".scrollingHotSpotRight");
$(rArrow).addClass("scrollingHotSpotRightVisible");
$(rArrow).css({"display":"block","height":sh,"top":pt})
});
}
else{
$(".pdtd-home-section-div").smoothDivScroll("disable");
$(".scrollableArea").css("width","200%")
}
	
	return homePageDataStr;
}
*/
/* Moved to seperate JS
function loadInflightHomePageData(homePageSession)
{

	//console.log("inside Inflight homepage");
	$("#arc2session").val(homePageSession.id); 
	$("#arc-home-widgets").css({"display":"none"});
	$("#inflight-home").css({"display":"table"});
	$("#home_folder_inflight_features_container").css({"display":"inline-block"});
	$("#home_folder_inflight_genre_container").css({"display":"inline-block"}); 
	var url_inflight="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	$.ajax(
	{
		error:function(res){},
		success:function(res){
		console.log("Res: " + res)
		loadInflightHomePageReleases(res);
		},
		url:url_inflight
	});
	
	var url_inflight_features = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=features";
	$.ajax({url:url_inflight_features,success:function(res){
		
		homePageDataStr=getFolderBasedFeatures(res);
		if(homePageDataStr.trim()!=='')
		{			
			$("#home_folder_inflight_features").html(homePageDataStr);
		}
		
		//loadInflightHomePageFeatures(res);
	},error:function(res){}});
	
	$("#mm_upload_master").css({"display":"none"});

	if(otui.UserFETManager.isTokenAvailable("IMPORT"))
	{
		$("#inflight-upload-cell").css({"display":"block"});
		$("#inflight-upload").css({"display":""});
		$("#mm_upload_master_inflight").css({"display":"inline-table","width":"100%",
				"height":$("#inflight-upload").height()+"px"});
	}
}	


function loadInflightHomePageReleases(homePageData)
{
  //console.log("inside homepage file method name loadInflightHomePageReleases"+JSON.stringify(homePageData));
  var homePageLinkList=homePageData.homePageLinkList;
  var homePageDataStr="";
  if(homePageLinkList!='')
  {
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   var folderName=homePageLinkList[i].folderName;
	   if(homePageTitleList!='')
	   {
			numberOfFolders++;
			homePageDataStr+= "<tr><td class=\"inflight_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			var numberOfTitles = homePageTitleList.length;
			homePageDataStr+="<tr><td valign=\"top\">";
			homePageDataStr+="<div class=\"inflight-home-section-div_" + i + "\" id=\"inflight-home-section-div_" + i + "\">";
		   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				homePageDataStr+="<div" + " class = \"carousel-tile\"  onmouseover=\"javascript:this.getElementsByClassName('inflight-home-title-hover')[0].style.display='inline-flex';\""
												+ " onmouseout=\"javascript:this.getElementsByClassName('inflight-home-title-hover')[0].style.display='none';\""
												+ " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="
												+ homePageTitlesDto.titleId + "';\">";
				homePageDataStr+="<div class=\"inflight-home-title-hover\">"
										+ "<table width=\"100%\" style=\"height: 100%;\"><tr>" + "<td valign=\"middle\">"
										+ homePageTitlesDto.titleName + "</td>"
										+ "</tr></table></div>"
										
						//console.log("title data:"+JSON.stringify(homePageTitlesDto));			
					if (homePageTitlesDto.screenResObjId=="") 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}
					else 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
									
						//console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
					}
					homePageDataStr+="<br/><span style='font-family: arial black;'>"+homePageTitlesDto.inflightRights
				homePageDataStr+="</span></div>";
		   
		   }
		   
		   homePageDataStr+="</div></td></tr><input type='hidden' name='numberOfTitles_" + i
									+ "' value=" + numberOfTitles + " id='numberOfTitles_" + i + "'/>";
	   }
	}
	homePageDataStr+="<input type='hidden' name='numberOfRelFolders' value="+numberOfFolders+" id='numberOfRelFolders'/>";
	}
	//console.log("inside homepage js homePageDataStr:"+homePageDataStr);
	
	//scroll code
	/*
	$("#inflight-home-section").html(homePageDataStr);
     
	var numFolders=document.getElementById('numberOfRelFolders').value;
	for(var i=0;i<numFolders;i+=1){
		var numTitles=document.getElementById('numberOfTitles_'+i).value;
		var scrollwrapperclassvar="scrollWrapper_"+i;
		console.log("Inside loop numTitles:"+numTitles);
		$("#inflight-home-section-div_"+i).smoothDivScroll({
                autoScrollingMode: "empty",
                hotSpotScrolling: false,
                manualContinuousScrolling: false,
                mousewheelScrolling: "allDirections",
		  scrollWrapperClass: scrollwrapperclassvar,
                touchScrolling: false
            });
		$(".scrollableArea").css("width","200%");
		$("."+scrollwrapperclassvar).css({"height":"100%","overflow":"hidden","position":"relative","width":"100%"});
		if(numTitles>3){
			$("."+scrollwrapperclassvar).hover(function(){
			//console.log("**numTitles:"+numTitles);
			var sh=$(this).height()+"px";
			var pt=$(this).position().top+"px";
			var lArrow=$(this).parent().find(".scrollingHotSpotLeft");
			$(lArrow).addClass("scrollingHotSpotLeftVisible");
			$(lArrow).css({"display":"block","height":sh});
			var rArrow=$(this).parent().find(".scrollingHotSpotRight");
			$(rArrow).addClass("scrollingHotSpotRightVisible");
			$(rArrow).css({"display":"block","height":sh})				
			});
		}
		else{
			$(".inflight-home-section-div_"+i).smoothDivScroll("disable");
			$(".scrollableArea").css("width","200%")
		}
	}
	
	return homePageDataStr;
}
*/

function getFolderBasedFeatures(homePageData)
{
	
	var homePageDataStr="";
	var roleName=(JSON.parse(sessionStorage.session)).role_name;
	//console.log("roleName:"+roleName);	
	var homePageLinkList=homePageData.homePageLinkList;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
		 var folderName=homePageLinkList[i].folderName;
		 var folderId=homePageLinkList[i].folderId;
		 
		 	
		/*homePageDataStr+="<div onclick=\"javascript:";
		homePageDataStr+="FolderManager.performAdvancedSearch('"+ folderId
						+"','||advancedSearch||',"
						+ "{"
						+ "'names':['"+ homePageData.homePageFolderName +"','"+ folderName+"'],"
						+ "'ids':['"+ homePageData.homePageFolderFolderId+"','"+ folderId+"']"
						+ "},"
						+ "'"+homePageData.homePageSearchconfigId+"','"+homePageData.homePageSearchsearchName+"',"
						+"{'search_condition':[]},"
						+ "'ARTESIA.FIELD.DATE IMPORTED','desc',undefined,'en_US','3','Metadata and File Content');\">";
				homePageDataStr+=folderName + "</div>";*/
		
		
		homePageDataStr+="<a href='/otmm/go/folder/"+folderId+"'><div>";
				homePageDataStr+=folderName + "</div></a>";
	  
	}
	
	return homePageDataStr;
}
function loadInflightHomePageFeatures(homePageData)
{
	//console.log("inside loadInflightHomePageFeatures"+JSON.stringify(homePageData));
	
	
	
	
	
	return homePageDataStr;

}
/*
function loadLicHomePageData(homePageSession)
{
	//console.log("inside Lic homepage");
	
	$("#arc2session").val(homePageSession.id);
	$("#arc-home-widgets").css({"display":"none"});
	$("#lic-home").css({"display":"table"});
	$("#home_folder_lic_container").css({"display":"inline-block"});
	var url_lic="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=''";
	
	$.ajax({error:function(res){},success:function(res){
	//console.log("inside lic home");	
	loadLicHOmePageTitles(res);
	
	$(".lic-home-title-hover").each(function(){
		var ih=$(this).next().height()+"px";
		var iw=$(this).next().width()+"px";
		$(this).css({"height":ih,"width":iw})
	});
	
	$(".ot-homescreen").scroll(function(){$(".lic-home-title-hover").each(
	function(){
	var it=$(this).next().position().top;$(this).css({"top":it})})});
	
	var hsh=$("#home_folder_lic_container").find(".lic_sec_header").html().trim();
	hsh=hsh+"<span class=\"lic-all-titles\">[&nbsp;<a href=\"/otmm/ux-html/?p=title\">View All Titles</a>&nbsp;]</span>";
	
	},
	url:url_lic}
	);
	

	if(otui.UserFETManager.isTokenAvailable("IMPORT")){
	$("#lic-upload-cell").css({"display":"block"});
	$("#lic-upload").css({"display":""});
	$("#mm_upload_master_lic").css({"display":"inline-table","height":
									$("#lic-upload").height()+"px","width":"100%"});
	}
}

function loadLicHOmePageTitles(homePageData)
{

	var homePageLinkList=homePageData.homePageLinkList;
	var homePageDataStr="";
	if(homePageLinkList!='')
	{
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   
	   if(homePageTitleList!='')
	   {
	   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				
				homePageDataStr+="<div " +
									" onmouseover=\"javascript:this.getElementsByClassName('lic-home-title-hover')[0].style.display='inline-flex';\"" +
									" onmouseout=\"javascript:this.getElementsByClassName('lic-home-title-hover')[0].style.display='none';\"" +
									" onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="+homePageTitlesDto.titleId+"';\">";
				homePageDataStr+="<div class=\"lic-home-title-hover\">" +
									"<table width=\"100%\" style=\"height: 100%;\"><tr>" +
									"<td valign=\"middle\">"+homePageTitlesDto.titleName +"</td>" +
									"</tr></table></div>";
				if(homePageTitlesDto.licensingThumbUoiId=='' || homePageTitlesDto.licensingThumbUoiId==null){
															
								homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
				}else{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.licensingThumbUoiId + "\"/>";
				}
							homePageDataStr+="</div>";
		   
		   }
	   }
	}
	}
	$("#home_folder_lic_current_titles").html(homePageDataStr);

}
*/
/*
function loadPheHomePageData(homePageSession)
{
	//console.log("inside PHE homepage");
	//Home page - PHE Start
	$("#arc2session").val(homePageSession.id);
	$("#arc-home-widgets").css({"display":"none"});
	$("#phe-home").css({"display":"table"});
	$("#home_folder_phe_features_container").css({"display":"inline-block"});
	$("#home_folder_phe_genre_container").css({"display":"inline-block"});
	var url_phe="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=releases";
	$.ajax(
		{
		error:function(res){},
		success:function(res)
		{ 
		var pheres=loadPheHomePageReleases(res);
		},
		url:url_phe
		}
	);
	
	var url_phe_features="/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=features";
	
	$.ajax(
		{
			error:function(res){},
			success:function(res){ 
								var pheFeatures=loadPheHomePageFeatures(res); 
								},
			url:url_phe_features
		}
	);
	
	$("#mm_upload_master").css({"display":"none"});
	
	if(otui.UserFETManager.isTokenAvailable("IMPORT"))
	{
		$("#phe-upload-cell").css({"display":"block"});
		$("#phe-upload").css({"display":""});
		$("#mm_upload_master_phe").css({"display":"inline-table","height":$("#phe-upload").height()+"px","width":"100%"});
	}
	
}


function loadPheHomePageReleases(homePageData)
{
  //console.log("inside homepage file method name loadPheHomePage"+JSON.stringify(homePageData));
  var homePageLinkList=homePageData.homePageLinkList;
  var homePageDataStr="";
  if(homePageLinkList!='')
  {
	  var numberOfFolders=0;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
	   var homePageTitleList=homePageLinkList[i].homePageTitleList;
	   var folderName=homePageLinkList[i].folderName;
	   if(homePageTitleList!='')
	   {
			numberOfFolders++;
			homePageDataStr+= "<tr><td class=\"phe_sec_header\">"
								+ folderName.substring(folderName.indexOf("_") + 1) + "</td></tr>";
			var numberOfTitles = homePageTitleList.length;
			homePageDataStr+="<tr><td valign=\"top\">";
			homePageDataStr+="<div class=\"phe-home-section-div_" + i + "\" id=\"phe-home-section-div_" + i + "\">";
		   for(var j=0;j<homePageTitleList.length;j++)
		   {
				var homePageTitlesDto=homePageTitleList[j];
				homePageDataStr+="<div" + " class = \"carousel-tile\" onmouseover=\"javascript:this.getElementsByClassName('phe-home-title-hover')[0].style.display='inline-flex';\""
												+ " onmouseout=\"javascript:this.getElementsByClassName('phe-home-title-hover')[0].style.display='none';\""
												+ " onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="
												+ homePageTitlesDto.titleId + "';\">";
				homePageDataStr+="<div class=\"phe-home-title-hover\">"
										+ "<table width=\"100%\" style=\"height: 100%;\"><tr>" + "<td valign=\"middle\">"
										+ homePageTitlesDto.titleName + "</td>"
										+ "</tr></table></div>"
										
						//console.log("title data:"+JSON.stringify(homePageTitlesDto));			
					if (homePageTitlesDto.screenResObjId=="") 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\""
										+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}
					else 
					{
						homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
									+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
									+homePageTitlesDto.screenResObjId + "\"/>";
									
						//console.log("homePageTitlesDto.screenResObjId:"+homePageTitlesDto.screenResObjId);			
					}
				homePageDataStr+="</div>";
		   
		   }
		   
		   homePageDataStr+="</div></td></tr><input type='hidden' name='numberOfTitles_" + i
									+ "' value=" + numberOfTitles + " id='numberOfTitles_" + i + "'/>";
	   }
	}
	homePageDataStr+="<input type='hidden' name='numberOfRelFolders' value="+numberOfFolders+" id='numberOfRelFolders'/>";
	}
	//console.log("inside homepage js homePageDataStr:"+homePageDataStr);
	
	//scroll code
	$("#phe-home-section").html(homePageDataStr);
        var numFolders = document.getElementById('numberOfRelFolders').value;
		//console.log("numFolders:"+numFolders);
		
        for (var i = 0; i<numFolders; i = i + 1) {

            var numTitles = document.getElementById('numberOfTitles_' + i).value;
			//console.log("numTitles:"+numTitles);
            var scrollwrapperclassvar = "scrollWrapper_" + i;
            $("#phe-home-section-div_" + i).smoothDivScroll({
                autoScrollingMode: "empty",
                hotSpotScrolling: false,
                manualContinuousScrolling: false,
                mousewheelScrolling: "allDirections",
                scrollWrapperClass: scrollwrapperclassvar,
                touchScrolling: false
            });
            $(".scrollableArea").css("width", "200%");
            $("." + scrollwrapperclassvar).css({"height": "100%", "overflow": "hidden", "position": "relative", "width": "100%"});
            if (numTitles > 5) {
                $("." + scrollwrapperclassvar).hover(function () {
                    //console.log("phe numTitles:" + numTitles);
                    var sh = $(this).height() + "px";
                    var pt = $(this).position().top + "px";
                    var lArrow = $(this).parent().find(".scrollingHotSpotLeft");
                    $(lArrow).addClass("scrollingHotSpotLeftVisible");
                    $(lArrow).css({"display": "block", "height": sh, "top": pt});
                    var rArrow = $(this).parent().find(".scrollingHotSpotRight");
                    $(rArrow).addClass("scrollingHotSpotRightVisible");
                    $(rArrow).css({"display": "block", "height": sh, "top": pt})
                })
            } else {
                //console.log("inside else num title");
                $(".phe-home-section-div_" + i).smoothDivScroll("disable");
                $(".scrollableArea").css("width", "200%")
            }
        }
	
	return homePageDataStr;
}

function loadPheHomePageFeatures(homePageData)
{
	//console.log("inside loadPheHomePageFeatures"+JSON.stringify(homePageData));
	var homePageDataStr="";
	var roleName=(JSON.parse(sessionStorage.session)).role_name;
	//console.log("roleName:"+roleName);	
	var homePageLinkList=homePageData.homePageLinkList;
	  for(var i=0;i<homePageLinkList.length;i++)
	{
		 var folderName=homePageLinkList[i].folderName;
		 var folderId=homePageLinkList[i].folderId;
		 
		 	if(!(roleName.toLowerCase()=='phe external'&&
					(folderName.toLowerCase()=="phe tv spot"||
			      folderName.toLowerCase()=="retail style guides & templates"
					)
				 )
			&&
				!( roleName.toLowerCase()=="phe regular - no upload"&&															 
			       folderName.toLowerCase()=="retail style guides & templates"
				  )
				)
			{
				//homePageDataStr+="<div onclick=\"javascript:";
				//homePageDataStr+="FolderManager.performAdvancedSearch('"+ folderId
								//+"','*',"
								//+ "{"
								//+ "'names':['"+ homePageData.homePageFolderName +"','"+ folderName+"'],"
								//+ "'ids':['"+ homePageData.homePageFolderFolderId+"','"+ folderId+"']"
								//+ "},"
								//+ "'"+homePageData.homePageSearchconfigId+"','"+homePageData.homePageSearchsearchName+"',"
								//+"{'search_condition':[]},"
								//+ "'ARTESIA.FIELD.DATE IMPORTED','desc',undefined,'en_US','3','Metadata and File Content');\">";
				homePageDataStr+="<a href='/otmm/go/folder/"+folderId+"'><div>";
				homePageDataStr+=folderName + "</div></a>";
		}
		
	  
	}
	
	if(homePageDataStr.trim()!=='')
		{
			$("#home_folder_phe_features_container").css({"display":"inline-block"});
			$("#home_folder_phe_features").html(homePageDataStr);
		}
	
	//add extra link
	var res1="";
	var query = window.location;

	if(query.host == "enterprise.viacomcbs.com" || query.host == "enterpriseuat.viacomcbs.com" || query.host == "10.224.79.142:11090")
	{
	res1  =  "<div onclick=\"javascript:showRequestForm();\">Request Form</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'452','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'444','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'448','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'106','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div>";
        if (roleName.toLowerCase() != 'phe external') {
            res1 = res1 + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'276','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'141','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'277','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Backlot</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'57','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'1','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'5','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'328','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'237','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'12','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'16','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'17','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'74','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'255','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'96','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'132','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'133','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'134','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'136','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'138','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'178','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'199','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'203','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'208','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'212','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'228','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'235','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Multi-Title</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'298','left_paren':'(','relational_operator':'and','right_paren':')'}]},'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Ratings</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'10972', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'430','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'459','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'460','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'458','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'449','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Templates</div>";
        }
	}
	else if(query.host == "10.224.5.113:11090")
		{
		res1  =  "<div onclick=\"javascript:showRequestForm();\">Request Form</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'452','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'444','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'448','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'106','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Logos</div>";
	        if (roleName.toLowerCase() != 'phe external') {
	            res1 = res1 + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'276','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'141','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'277','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Backlot</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'57','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'1','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'5','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'328','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'237','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'12','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'16','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'17','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'74','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'255','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'96','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'132','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'133','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'134','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'136','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'138','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'178','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'199','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'109','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'203','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'208','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'212','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'228','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'235','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">Multi-Title</div>" + "<div onclick=\"javascript:otui.Search.performAdvancedSearch(undefined, '||advancedSearch||', {'names': [],'ids': []},'1581', 'PHE Assets', {'search_condition':[{'type':'com.artesia.search.SearchTabularCondition','metadata_table_id':'CUSTOM.FIELD.ASSET TITLE','tabular_field_list':[{'type':'com.artesia.search.SearchTabularFieldCondition','metadata_field_id':'TITLE.ID','relational_operator_id':'ARTESIA.OPERATOR.NUMBER.IS','value':'999992'}]},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':	'298','left_paren':'(','relational_operator':'and','right_paren':')'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'430','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'459','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'460','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'458','relational_operator':'or'},{'type':'com.artesia.search.SearchScalarCondition','metadata_field_id':'CUSTOM.FIELD.ASSET TYPE','relational_operator_id':'ARTESIA.OPERATOR.CHAR.CONTAINS','value':'449','relational_operator':'or'}]}, 'ARTESIA.FIELD.DATE IMPORTED', 'desc', 'en_US','3','Metadata and File Content');\">ToolBox</div>";
	        }	
		}		
		
	if (res1.trim() !== '') {
            $("#home_folder_phe_features_container").css({"display": "inline-block"});
            $("#home_folder_phe_features1").html(res1);
        }
	//console.log("homePageDataStr:"+homePageDataStr);
	return homePageDataStr;

}
*/
function showRequestForm() {
    //console.log("inside show RequestForm");
    $("ot-view[ot-view-type='RequestFormView']").css({
        "left": "15%",
        "top": "10%",
        "width": "50%",
        "height": "50%"
    });
    $("ot-view[ot-view-type='RequestFormView'] .ot-modal-dialog-body").css({
        "overflow-y": "auto"
    });
    //console.log("select:" + $("#typeOfRequest"));
    $("#typeOfRequest").append(new Option('Foo', 'foo', true, true));
    RequestFormView.asDialog();
    $("#requestFormDiv").css({
        "display": "block"
    });
}

/* HtoA - START*/
function loadHiveHomePageData(homePageSession){
	var homePageSession="";
	var roleName ="";
	if(sessionStorage&&sessionStorage.session){
		homePageSession=JSON.parse(sessionStorage.session);roleName = (JSON.parse(sessionStorage.session)).role_name;
	}
	
	var url_hive_home ="/EnterpriseHomePage/hive/home?sId=" + homePageSession.id;
	$.ajax({
                error  : function (res) {},
                success: function (res) {                          
				  $("#hiveHomeScreen").html(res.replace(/DQUOTE/g, '"').replace(/v3/g, 'v5'));						  						 
                },
                url    : url_hive_home
            });

	$("#hiveHomeScreen").show();
	$(".ot-homescreen").css({"display":"none"});

	
}
/* HtoA - END*/
/*
function loadPPCHomepageData(homePageSession)
	{
		$("#ppc-home").css({"display":"table"});
		$("#home_folder_ppc_container").css({"display":"inline-block"});
		$("#titleLoadingDiv").css({"display":"block", "margin-left":"40%"});
		var url_pk = "/EnterpriseHomePage/homepage?sId="+homePageSession.id+"&sec=''";
		$.ajax({url:url_pk,success:function(res){
			var homePageDataStr=loadPPCHomePageTitles(res);
			$("#home_folder_ppc_current_titles").html(homePageDataStr);
			$(".ppc-home-title-hover").each(function(){
				var ih=$(this).next().height()+"px";
				var iw=$(this).next().width()+"px";
				$(this).css({"height":ih,"width":iw});});
				$(".ot-homescreen").scroll(function(){
					$(".ppc-home-title-hover").each(function(){
						var it=$(this).next().position().top;$(this).css({"top":it});});
						});
				
				var hsh=$("#home_folder_ppc_container").find(".ppc_sec_header").html();
				hsh=hsh+"<span class=\"ppc-all-titles\">[&nbsp;<a href=\"/otmm/ux-html/?p=title\">View All Titles</a>&nbsp;]</span>";$("#home_folder_ppc_container").find(".ppc_sec_header").html(hsh);	
				
				},
				error:function(res){}
				});
			if(otui.UserFETManager.isTokenAvailable("IMPORT")){
				$("#ppc-upload-cell").css({"display":"block"});
				$("#ppc-upload").css({"display":""});
				$("#mm_upload_master_ppc").css({"display":"inline-table","width":"100%","height":$("#ppc-upload").height()+"px"});
				}
			$("#titleLoadingDiv").css({"display":"none"});
	}

	function loadPPCHomePageTitles(homePageData)
	{

		var homePageLinkList=homePageData.homePageLinkList;
		var companyName = homePageData.homePageLinkList[0].companyName;
		var homePageDataStr="";
		var hasWatemarkTemplateFET = otui.UserFETManager.isTokenAvailable("PP_WATERMARK_TEMPLATE");
		if(homePageLinkList!='')
		{
		  var numberOfFolders=0;
		  for(var i=0;i<homePageLinkList.length;i++)
		{
		   var homePageTitleList=homePageLinkList[i].homePageTitleList;
		   
		   if(homePageTitleList!='')
		   {
		   for(var j=0;j<homePageTitleList.length;j++)
			   {
					var homePageTitlesDto=homePageTitleList[j];
					
					homePageDataStr+="<div " +
										" onmouseover=\"javascript:this.getElementsByClassName('ppc-home-title-hover')[0].style.display='inline-flex';\"" +
										" onmouseout=\"javascript:this.getElementsByClassName('ppc-home-title-hover')[0].style.display='none';\"" +
										" onclick=\"javascript:window.location='/otmm/ux-html/?p=title&title="+homePageTitlesDto.titleId+"';\">";

					homePageDataStr+="<div class=\"ppc-home-title-hover\">" +
					"<table width=\"100%\" style=\"height: 100%; background-color:#000099; opacity:0.5;\"><tr>" +
					"<td valign=\"middle\">"+homePageTitlesDto.titleName +"</td>" +
					"</tr></table></div>";

					if(homePageTitlesDto.ppThumbUoiId =='' || homePageTitlesDto.ppThumbUoiId == 'null' || homePageTitlesDto.ppThumbUoiId == null){
																
									homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
											+ "\" style=\"border: none;\" src=\""
											+ "/otmm/ux-html/customizations/common/img/arc2/common/no_title_thumbnail_title_page.jpg" + "\"/>";
					}else {
						if(!hasWatemarkTemplateFET){

							if(homePageTitlesDto.templateId=='' || homePageTitlesDto.templateId== 'null' || homePageTitlesDto.templateId== null){
								homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
										+homePageTitlesDto.ppThumbUoiId+ "\"/>";
							}else{
								homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
											+ "\" style=\"border: none;\" src=\""
											+ "/otmm/ux-html/customizations/common/img/arc2/common/preview_unavailable.png" + "\"/>";

							}

						}else{
							homePageDataStr+="<img title=\"" + homePageTitlesDto.titleName
										+ "\" style=\"border: none;\" src=\"/otmmapi/v6/renditions/"
										+homePageTitlesDto.ppThumbUoiId+ "\"/>";
						}
						
					}
								//homePageDataStr+="<br/>" + homePageTitlesDto.titleName+"</a></div>";
								homePageDataStr+="</div>";
			   
			   }
		   }
			  
		   
		}
		  if(companyName != null){
			   $("#ppc-welcome-company").html("Welcome "+companyName);
			}else{
			   $(".ppc_welcome_sec_header").css({"display":"none"}); 
			}
		}
		return homePageDataStr;

	}
*/